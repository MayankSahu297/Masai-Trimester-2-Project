import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, useLocation } from 'wouter';
import MenuItem from '@/components/restaurant/MenuItem';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';

const RestaurantDetails = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const [activeCategory, setActiveCategory] = useState('recommended');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch restaurant details
  const { data: restaurant, isLoading: isLoadingRestaurant } = useQuery({
    queryKey: [`/api/restaurants/${id}`],
  });
  
  // Fetch menu items for the restaurant
  const { data: menuItems, isLoading: isLoadingMenu } = useQuery({
    queryKey: [`/api/restaurants/${id}/menu`],
  });
  
  // Filter menu items by category and search query
  const filteredMenuItems = menuItems?.filter((item: any) => {
    const matchesCategory = activeCategory === 'recommended' || item.category.toLowerCase() === activeCategory.toLowerCase();
    const matchesSearch = !searchQuery || 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.tags && item.tags.some((tag: string) => tag.toLowerCase().includes(searchQuery.toLowerCase())));
    
    return matchesCategory && matchesSearch;
  });
  
  // Get unique categories from menu items
  const getCategories = () => {
    if (!menuItems) return [];
    
    const categories = new Set<string>();
    categories.add('recommended');
    
    menuItems.forEach((item: any) => {
      categories.add(item.category);
    });
    
    return Array.from(categories);
  };
  
  const handleBack = () => {
    navigate('/');
  };
  
  const isLoading = isLoadingRestaurant || isLoadingMenu;
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!restaurant) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="text-6xl text-gray-300 mb-4">
          <i className="fas fa-exclamation-circle"></i>
        </div>
        <h3 className="text-xl font-medium text-secondary mb-2">Restaurant not found</h3>
        <p className="text-textGray mb-6">The restaurant you're looking for doesn't exist or has been removed</p>
        <Button onClick={handleBack}>Back to Restaurants</Button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-4">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <button className="text-secondary hover:text-primary" onClick={handleBack}>
          <i className="fas fa-arrow-left text-xl"></i>
        </button>
        <div className="flex space-x-4">
          <button className="text-secondary hover:text-primary">
            <i className="far fa-heart text-xl"></i>
          </button>
          <button className="text-secondary hover:text-primary">
            <i className="fas fa-share-alt text-xl"></i>
          </button>
        </div>
      </div>
      
      {/* Restaurant Info */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-6 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-secondary mb-1 brand-font">{restaurant.name}</h1>
          <p className="text-textGray text-sm">{restaurant.cuisineTypes.join(', ')}</p>
          <p className="text-textGray text-sm mt-1">Bangalore, Karnataka</p>
          <div className="flex items-center mt-3 text-sm">
            <span className="bg-success text-white px-1.5 py-0.5 rounded flex items-center mr-3">
              <span>{restaurant.rating}</span>
              <i className="fas fa-star text-xs ml-1"></i>
            </span>
            <span className="border-r border-gray-300 pr-3">200+ Ratings</span>
            <span className="px-3 border-r border-gray-300">{restaurant.deliveryTime} mins</span>
            <span className="pl-3">₹{restaurant.priceForTwo} for two</span>
          </div>
        </div>
        <div className="mt-4 md:mt-0">
          <div className="bg-blue-50 p-3 rounded-lg">
            <p className="text-xs text-textGray mb-1">OFFERS</p>
            {restaurant.offers?.map((offer, index) => (
              <div key={index} className="flex items-center text-sm mb-2">
                <i className="fas fa-tag text-primary mr-2"></i>
                <span className="text-secondary font-medium">{offer}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search menu items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
      </div>
      
      {/* Menu Categories */}
      <Tabs value={activeCategory} onValueChange={setActiveCategory} className="mb-6">
        <TabsList className="flex overflow-x-auto hide-scrollbar mb-2 pb-2 border-b border-gray-200">
          {getCategories().map((category) => (
            <TabsTrigger 
              key={category} 
              value={category}
              className="whitespace-nowrap py-2 px-4 text-textGray hover:text-secondary data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:font-medium"
            >
              {category === 'recommended' ? 'Recommended' : category}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {getCategories().map((category) => (
          <TabsContent key={category} value={category} className="mb-12">
            <h2 className="text-xl font-bold text-secondary mb-4 brand-font">
              {category === 'recommended' ? 'Recommended' : category} 
              {filteredMenuItems && `(${filteredMenuItems.length})`}
            </h2>
            
            {filteredMenuItems?.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-textGray">No items found in this category</p>
              </div>
            ) : (
              filteredMenuItems?.map((menuItem: any) => (
                <MenuItem 
                  key={menuItem.id} 
                  menuItem={menuItem}
                  restaurant={restaurant}
                />
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default RestaurantDetails;
