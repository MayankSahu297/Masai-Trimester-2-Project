import { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';

const OrderTracking = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  
  // Fetch order details
  const { data: order, isLoading, error, refetch } = useQuery({
    queryKey: [`/api/orders/${id}`],
  });
  
  // Set up polling for order updates
  useEffect(() => {
    // Poll for updates every 30 seconds
    const interval = setInterval(() => {
      refetch();
    }, 30000);
    
    return () => clearInterval(interval);
  }, [refetch]);
  
  const handleBackToHome = () => {
    navigate('/');
  };
  
  // Helper function to format dates
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  // Get status for timeline display
  const getStatusClass = (statusCheck: string) => {
    if (!order) return 'bg-gray-300';
    
    const statusOrder = ['placed', 'confirmed', 'preparing', 'on_the_way', 'delivered'];
    const currentIndex = statusOrder.indexOf(order.status);
    const checkIndex = statusOrder.indexOf(statusCheck);
    
    if (currentIndex >= checkIndex) return 'bg-success';
    return 'bg-gray-300';
  };
  
  // Get status icon
  const getStatusIcon = (statusCheck: string) => {
    switch (statusCheck) {
      case 'placed':
        return 'fas fa-check';
      case 'confirmed':
        return 'fas fa-check';
      case 'preparing':
        return 'fas fa-utensils';
      case 'on_the_way':
        return 'fas fa-motorcycle';
      case 'delivered':
        return 'fas fa-flag-checkered';
      default:
        return 'fas fa-check';
    }
  };
  
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (error || !order) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <div className="text-6xl text-gray-300 mb-4">
          <i className="fas fa-exclamation-circle"></i>
        </div>
        <h3 className="text-xl font-medium text-secondary mb-2">Order not found</h3>
        <p className="text-textGray mb-6">The order you're looking for doesn't exist or has been removed</p>
        <Button onClick={handleBackToHome}>Back to Home</Button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <button className="text-secondary hover:text-primary" onClick={handleBackToHome}>
          <i className="fas fa-arrow-left text-xl"></i>
        </button>
        <h1 className="text-xl font-bold text-secondary brand-font">Order Status</h1>
        <button className="text-secondary hover:text-primary">
          <i className="fas fa-ellipsis-v text-xl"></i>
        </button>
      </div>
      
      {/* Order Info */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="font-bold text-secondary">{order.restaurant.name}</h2>
            <p className="text-sm text-textGray mt-1">Order #{order.id}</p>
            <p className="text-sm text-textGray mt-1">{order.items.length} Items • ₹{order.totalAmount}</p>
          </div>
          <div className={`
            ${order.status === 'placed' ? 'bg-amber-50 text-amber-700' : ''}
            ${order.status === 'confirmed' ? 'bg-amber-50 text-amber-700' : ''}
            ${order.status === 'preparing' ? 'bg-blue-50 text-blue-700' : ''}
            ${order.status === 'on_the_way' ? 'bg-blue-50 text-blue-700' : ''}
            ${order.status === 'delivered' ? 'bg-green-50 text-green-700' : ''}
            ${order.status === 'cancelled' ? 'bg-red-50 text-red-700' : ''}
            px-3 py-1 rounded-full text-sm font-medium
          `}>
            {order.status === 'placed' ? 'Order Placed' : ''}
            {order.status === 'confirmed' ? 'Order Confirmed' : ''}
            {order.status === 'preparing' ? 'Preparing' : ''}
            {order.status === 'on_the_way' ? 'On the way' : ''}
            {order.status === 'delivered' ? 'Delivered' : ''}
            {order.status === 'cancelled' ? 'Cancelled' : ''}
          </div>
        </div>
      </div>
      
      {/* Delivery Info */}
      {order.status === 'on_the_way' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex items-start">
            <div className="w-20 h-20 rounded-lg bg-blue-100 flex items-center justify-center text-blue-500 text-3xl mr-4">
              <i className="fas fa-motorcycle"></i>
            </div>
            <div>
              <h2 className="font-bold text-secondary">Your order is on the way</h2>
              <p className="text-sm text-textGray mt-1">Delivery Partner</p>
              <div className="flex mt-3">
                <button className="bg-primary text-white rounded-full w-8 h-8 flex items-center justify-center mr-3">
                  <i className="fas fa-phone-alt"></i>
                </button>
                <Button variant="outline" className="border border-primary text-primary rounded-full px-3 py-1 text-sm font-medium">
                  Track Order
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Order Timeline */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <h2 className="font-bold text-secondary mb-4">Order Status</h2>
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          
          {/* Timeline items */}
          <div className="relative pl-10 pb-6">
            <div className={`absolute left-0 w-6 h-6 rounded-full ${getStatusClass('placed')} text-white flex items-center justify-center`}>
              <i className={`${getStatusIcon('placed')} text-xs`}></i>
            </div>
            <h3 className="font-medium text-secondary">Order Placed</h3>
            <p className="text-xs text-textGray mt-1">
              {order.statusHistory && order.statusHistory.length > 0 
                ? formatDate(order.statusHistory[0].timestamp) 
                : formatDate(order.placedAt)}
            </p>
          </div>
          
          <div className="relative pl-10 pb-6">
            <div className={`absolute left-0 w-6 h-6 rounded-full ${getStatusClass('confirmed')} text-white flex items-center justify-center`}>
              <i className={`${getStatusIcon('confirmed')} text-xs`}></i>
            </div>
            <h3 className={`font-medium ${order.status === 'confirmed' || order.status === 'preparing' || order.status === 'on_the_way' || order.status === 'delivered' ? 'text-secondary' : 'text-textGray'}`}>
              Order Confirmed
            </h3>
            <p className="text-xs text-textGray mt-1">
              {order.statusHistory && order.statusHistory.find(s => s.status === 'confirmed')
                ? formatDate(order.statusHistory.find(s => s.status === 'confirmed').timestamp)
                : 'Pending'}
            </p>
          </div>
          
          <div className="relative pl-10 pb-6">
            <div className={`absolute left-0 w-6 h-6 rounded-full ${getStatusClass('preparing')} text-white flex items-center justify-center`}>
              <i className={`${getStatusIcon('preparing')} text-xs`}></i>
            </div>
            <h3 className={`font-medium ${order.status === 'preparing' || order.status === 'on_the_way' || order.status === 'delivered' ? 'text-secondary' : 'text-textGray'}`}>
              Food is Being Prepared
            </h3>
            <p className="text-xs text-textGray mt-1">
              {order.statusHistory && order.statusHistory.find(s => s.status === 'preparing')
                ? formatDate(order.statusHistory.find(s => s.status === 'preparing').timestamp)
                : 'Pending'}
            </p>
          </div>
          
          <div className="relative pl-10 pb-6">
            <div className={`absolute left-0 w-6 h-6 rounded-full ${getStatusClass('on_the_way')} text-white flex items-center justify-center`}>
              <i className={`${getStatusIcon('on_the_way')} text-xs`}></i>
            </div>
            <h3 className={`font-medium ${order.status === 'on_the_way' || order.status === 'delivered' ? 'text-secondary' : 'text-textGray'}`}>
              Food Picked Up, On the Way
            </h3>
            <p className="text-xs text-textGray mt-1">
              {order.statusHistory && order.statusHistory.find(s => s.status === 'on_the_way')
                ? formatDate(order.statusHistory.find(s => s.status === 'on_the_way').timestamp)
                : 'Pending'}
            </p>
            {order.status === 'on_the_way' && order.estimatedDeliveryTime && (
              <p className="text-xs text-primary mt-1">Expected delivery in {order.estimatedDeliveryTime} minutes</p>
            )}
          </div>
          
          <div className="relative pl-10">
            <div className={`absolute left-0 w-6 h-6 rounded-full ${getStatusClass('delivered')} text-white flex items-center justify-center`}>
              <i className={`${getStatusIcon('delivered')} text-xs`}></i>
            </div>
            <h3 className={`font-medium ${order.status === 'delivered' ? 'text-secondary' : 'text-textGray'}`}>
              Delivered
            </h3>
            <p className="text-xs text-textGray mt-1">
              {order.statusHistory && order.statusHistory.find(s => s.status === 'delivered')
                ? formatDate(order.statusHistory.find(s => s.status === 'delivered').timestamp)
                : 'Pending'}
            </p>
          </div>
        </div>
      </div>
      
      {/* Order Items */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-20">
        <h2 className="font-bold text-secondary mb-4">Order Details</h2>
        
        {/* Order Items */}
        {order.items.map((item) => (
          <div key={item.id} className="flex justify-between items-center border-b border-gray-100 py-3">
            <div className="flex items-center">
              <span className={`w-4 h-4 flex items-center justify-center border text-xs mr-3 ${
                item.menuItem.isVeg ? 'border-success text-success' : 'border-red-500 text-red-500'
              }`}>
                <i className="fas fa-circle"></i>
              </span>
              <div>
                <h3 className="font-medium text-secondary text-sm">{item.menuItem.name}</h3>
                <p className="text-xs text-textGray mt-1">Qty: {item.quantity}</p>
              </div>
            </div>
            <p className="text-sm text-secondary">₹{item.totalPrice}</p>
          </div>
        ))}
        
        {/* Bill Details */}
        <div className="mt-6 pt-3 border-t border-gray-200">
          <div className="flex justify-between mb-2 text-sm">
            <span className="text-textGray">Item Total</span>
            <span className="text-secondary">₹{order.totalAmount - order.deliveryFee - order.tax}</span>
          </div>
          <div className="flex justify-between mb-2 text-sm">
            <span className="text-textGray">Delivery Fee</span>
            <span className="text-secondary">₹{order.deliveryFee}</span>
          </div>
          <div className="flex justify-between mb-2 text-sm">
            <span className="text-textGray">GST and Restaurant Charges</span>
            <span className="text-secondary">₹{order.tax}</span>
          </div>
          <div className="flex justify-between font-bold mt-3 pt-3 border-t border-gray-200">
            <span className="text-secondary">Total Paid</span>
            <span className="text-secondary">₹{order.totalAmount}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderTracking;
