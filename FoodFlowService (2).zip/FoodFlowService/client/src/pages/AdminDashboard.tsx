import { useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import StatsCard from '@/components/admin/StatsCard';
import SalesChart from '@/components/admin/SalesChart';
import MenuManagement from '@/components/admin/MenuManagement';
import OrdersList from '@/components/admin/OrdersList';
import { Button } from '@/components/ui/button';

const AdminDashboard = () => {
  const [, navigate] = useLocation();
  const [selectedRestaurantId, setSelectedRestaurantId] = useState<number>(1); // Default to first restaurant
  const [dateRange, setDateRange] = useState<{ startDate?: Date; endDate?: Date }>({});
  
  // Demo mode - direct access enabled
  const user = { id: 1, name: 'Admin User' };
  const isAdmin = true;
  
  // Fetch restaurants for admin
  const { data: restaurants } = useQuery({
    queryKey: ['/api/restaurants'],
  });
  
  // Fetch analytics for the selected restaurant
  const { data: analytics, isLoading: isLoadingAnalytics } = useQuery({
    queryKey: [`/api/analytics/${selectedRestaurantId}`, dateRange.startDate, dateRange.endDate],
  });
  
  const handleBackToUser = () => {
    navigate('/');
  };
  
  const handleRestaurantChange = (restaurantId: number) => {
    setSelectedRestaurantId(restaurantId);
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold text-secondary brand-font">Restaurant Dashboard</h1>
            <p className="text-sm text-textGray mt-1">
              {restaurants?.find((r: any) => r.id === selectedRestaurantId)?.name || 'Loading...'}
            </p>
          </div>
          <Button onClick={handleBackToUser} className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
            Exit Admin
          </Button>
        </div>
        
        {/* Restaurant Selector */}
        {restaurants && restaurants.length > 1 && (
          <div className="mt-4">
            <label className="block text-sm font-medium text-textGray mb-2">Select Restaurant</label>
            <select 
              value={selectedRestaurantId}
              onChange={(e) => handleRestaurantChange(Number(e.target.value))}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
            >
              {restaurants.map((restaurant: any) => (
                <option key={restaurant.id} value={restaurant.id}>
                  {restaurant.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>
      
      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList className="w-full border-b border-gray-200 mb-6">
          <TabsTrigger value="dashboard" className="px-4 py-2 text-textGray data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary">
            Dashboard
          </TabsTrigger>
          <TabsTrigger value="menu" className="px-4 py-2 text-textGray data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary">
            Menu Management
          </TabsTrigger>
          <TabsTrigger value="orders" className="px-4 py-2 text-textGray data-[state=active]:text-primary data-[state=active]:border-b-2 data-[state=active]:border-primary">
            Orders
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <StatsCard 
              title="Today's Orders"
              value={analytics?.totalOrders || 0}
              trend="+8% from yesterday"
              trendUp={true}
              icon="fas fa-shopping-bag"
              iconClass="bg-blue-100 text-blue-600"
              isLoading={isLoadingAnalytics}
            />
            
            <StatsCard 
              title="Today's Revenue"
              value={`₹${analytics?.revenue || 0}`}
              trend="+12% from yesterday"
              trendUp={true}
              icon="fas fa-rupee-sign"
              iconClass="bg-green-100 text-green-600"
              isLoading={isLoadingAnalytics}
            />
            
            <StatsCard 
              title="Pending Orders"
              value={analytics?.pendingOrders || 0}
              trend="Need immediate attention"
              trendUp={false}
              icon="fas fa-clock"
              iconClass="bg-amber-100 text-amber-600"
              isLoading={isLoadingAnalytics}
            />
          </div>
          
          {/* Analytics Chart */}
          <SalesChart analytics={analytics} isLoading={isLoadingAnalytics} />
        </TabsContent>
        
        <TabsContent value="menu">
          <MenuManagement restaurantId={selectedRestaurantId} />
        </TabsContent>
        
        <TabsContent value="orders">
          <OrdersList restaurantId={selectedRestaurantId} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
