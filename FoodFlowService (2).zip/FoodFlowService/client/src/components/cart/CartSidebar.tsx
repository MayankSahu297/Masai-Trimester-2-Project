import { useState } from 'react';
import { useLocation } from 'wouter';
import { useCart } from '@/hooks/use-cart';
import { useAuth } from '@/hooks/use-auth';
import CartItem from './CartItem';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

const CartSidebar = () => {
  const { cart, closeCart, getCartTotal, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);
  
  const { subtotal, tax, deliveryFee, total } = getCartTotal();
  
  const handleCheckout = async () => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be signed in to place an order",
        variant: "destructive",
      });
      return;
    }
    
    if (!cart.restaurant || cart.items.length === 0) {
      toast({
        title: "Empty cart",
        description: "Please add items to your cart before checking out",
        variant: "destructive",
      });
      return;
    }
    
    setIsProcessing(true);
    
    try {
      // Prepare order data
      const order = {
        restaurantId: cart.restaurant.id,
        customerId: user.id,
        status: "placed",
        totalAmount: total,
        deliveryFee,
        tax,
        paymentMethod: "cash_on_delivery", // Default payment method
      };
      
      // Prepare order items
      const items = cart.items.map(item => ({
        menuItemId: item.menuItem.id,
        quantity: item.quantity,
        unitPrice: item.menuItem.price,
        totalPrice: item.menuItem.price * item.quantity,
        specialInstructions: item.specialInstructions,
      }));
      
      const response = await apiRequest('POST', '/api/orders', { order, items });
      const newOrder = await response.json();
      
      toast({
        title: "Order placed successfully!",
        description: `Your order #${newOrder.id} has been placed.`,
      });
      
      // Clear cart and redirect to order tracking
      clearCart();
      closeCart();
      navigate(`/order/${newOrder.id}`);
    } catch (error) {
      toast({
        title: "Failed to place order",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };
  
  return (
    <div className="fixed top-0 right-0 bottom-0 w-full md:w-96 bg-white shadow-lg z-50 overflow-y-auto">
      <div className="p-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-secondary brand-font">Your Cart</h2>
          <button onClick={closeCart} className="text-secondary hover:text-primary">
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>
        {cart.restaurant && (
          <div className="flex items-center mt-2">
            <p className="text-sm text-textGray">From <span className="font-medium text-secondary">{cart.restaurant.name}</span></p>
          </div>
        )}
      </div>
      
      <div className="p-4">
        {/* Cart items */}
        {cart.items.length > 0 ? (
          <>
            {cart.items.map((item) => (
              <CartItem key={item.menuItem.id} item={item} />
            ))}
            
            {/* Coupon */}
            <div className="mt-4 border border-dashed border-gray-300 rounded-lg p-3 flex justify-between items-center">
              <div className="flex items-center">
                <i className="fas fa-tag text-primary mr-3"></i>
                <span className="text-sm text-secondary">Apply Coupon</span>
              </div>
              <i className="fas fa-chevron-right text-textGray"></i>
            </div>
            
            {/* Bill Details */}
            <div className="mt-6">
              <h3 className="font-bold text-secondary mb-3">Bill Details</h3>
              <div className="flex justify-between mb-2 text-sm">
                <span className="text-textGray">Item Total</span>
                <span className="text-secondary">₹{subtotal}</span>
              </div>
              <div className="flex justify-between mb-2 text-sm">
                <span className="text-textGray">Delivery Fee</span>
                <span className="text-secondary">₹{deliveryFee}</span>
              </div>
              <div className="flex justify-between mb-2 text-sm">
                <span className="text-textGray">GST and Restaurant Charges</span>
                <span className="text-secondary">₹{tax}</span>
              </div>
              <div className="flex justify-between font-bold mt-3 pt-3 border-t border-gray-200">
                <span className="text-secondary">Total</span>
                <span className="text-secondary">₹{total}</span>
              </div>
            </div>
          </>
        ) : (
          <div className="text-center py-10">
            <div className="text-6xl text-gray-300 mb-4">
              <i className="fas fa-shopping-cart"></i>
            </div>
            <h3 className="text-xl font-medium text-secondary mb-2">Your cart is empty</h3>
            <p className="text-textGray mb-6">Add items to your cart and they will appear here</p>
            <Button variant="outline" onClick={closeCart}>
              Browse Restaurants
            </Button>
          </div>
        )}
      </div>
      
      {/* Checkout Button - Fixed to bottom */}
      {cart.items.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 md:w-96 md:left-auto bg-white border-t border-gray-200 p-4">
          <Button 
            onClick={handleCheckout}
            disabled={isProcessing || cart.items.length === 0}
            className="w-full py-3 bg-success text-white font-medium rounded-lg hover:bg-green-600 transition-colors"
          >
            {isProcessing ? "PROCESSING..." : "PROCEED TO PAY"}
          </Button>
        </div>
      )}
    </div>
  );
};

export default CartSidebar;
