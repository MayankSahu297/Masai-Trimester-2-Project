import { useCart } from '@/hooks/use-cart';
import { CartItemType } from '@shared/types';

type CartItemProps = {
  item: CartItemType;
};

const CartItem = ({ item }: CartItemProps) => {
  const { updateItemQuantity, removeFromCart } = useCart();
  const { menuItem, quantity } = item;
  
  const handleDecrease = () => {
    if (quantity > 1) {
      updateItemQuantity(menuItem.id, quantity - 1);
    } else {
      removeFromCart(menuItem.id);
    }
  };
  
  const handleIncrease = () => {
    updateItemQuantity(menuItem.id, quantity + 1);
  };
  
  return (
    <div className="flex justify-between items-center border-b border-gray-100 py-3">
      <div className="flex-1">
        <div className="flex items-center">
          <span className={`w-4 h-4 flex items-center justify-center border text-xs mr-2 ${
            menuItem.isVeg 
              ? 'border-success text-success' 
              : 'border-red-500 text-red-500'
          }`}>
            <i className="fas fa-circle"></i>
          </span>
          <h3 className="font-medium text-secondary text-sm">{menuItem.name}</h3>
        </div>
        <div className="flex items-center mt-2 ml-6">
          <button 
            onClick={handleDecrease}
            className="w-6 h-6 flex items-center justify-center text-primary border border-gray-300 rounded-sm"
          >
            <i className="fas fa-minus text-xs"></i>
          </button>
          <span className="mx-3 text-sm">{quantity}</span>
          <button 
            onClick={handleIncrease}
            className="w-6 h-6 flex items-center justify-center text-primary border border-gray-300 rounded-sm"
          >
            <i className="fas fa-plus text-xs"></i>
          </button>
        </div>
      </div>
      <p className="text-sm text-secondary">₹{menuItem.price * quantity}</p>
    </div>
  );
};

export default CartItem;
