import { useState } from 'react';
import { Bar, BarChart, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AnalyticsData } from '@shared/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

type SalesChartProps = {
  analytics?: AnalyticsData;
  isLoading?: boolean;
};

const SalesChart = ({ analytics, isLoading = false }: SalesChartProps) => {
  const [chartView, setChartView] = useState('revenue');
  
  // Prepare data for revenue by category chart
  const categoryData = analytics?.ordersByCategory?.map(item => ({
    name: item.category,
    revenue: item.revenue
  })) || [];
  
  // Prepare data for peak hours chart
  const peakHoursData = analytics?.peakHours?.map(item => ({
    name: item.hour,
    orders: item.orders
  })) || [];
  
  // Prepare data for popular items chart
  const popularItemsData = analytics?.mostOrderedItems?.map(item => ({
    name: item.name,
    orders: item.count
  })) || [];
  
  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <h2 className="font-bold text-secondary mb-4">Sales Analytics</h2>
        <div className="w-full h-64 md:h-80 bg-gray-100 animate-pulse rounded-lg"></div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
      <h2 className="font-bold text-secondary mb-4">Sales Analytics</h2>
      
      <Tabs value={chartView} onValueChange={setChartView} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="revenue">Revenue by Category</TabsTrigger>
          <TabsTrigger value="peak">Peak Hours</TabsTrigger>
          <TabsTrigger value="popular">Popular Items</TabsTrigger>
        </TabsList>
        
        <TabsContent value="revenue" className="w-full h-64 md:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={categoryData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                formatter={(value) => [`₹${value}`, 'Revenue']}
                labelFormatter={(label) => `Category: ${label}`}
              />
              <Legend />
              <Bar dataKey="revenue" name="Revenue (₹)" fill="#FC8019" />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>
        
        <TabsContent value="peak" className="w-full h-64 md:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={peakHoursData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                formatter={(value) => [value, 'Orders']}
                labelFormatter={(label) => `Time: ${label}`}
              />
              <Legend />
              <Bar dataKey="orders" name="Number of Orders" fill="#3D4152" />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>
        
        <TabsContent value="popular" className="w-full h-64 md:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={popularItemsData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                formatter={(value) => [value, 'Orders']}
                labelFormatter={(label) => `Item: ${label}`}
              />
              <Legend />
              <Bar dataKey="orders" name="Number of Orders" fill="#60B246" />
            </BarChart>
          </ResponsiveContainer>
        </TabsContent>
      </Tabs>
      
      <div className="flex flex-wrap justify-between mt-4">
        <div className="w-1/2 md:w-1/4 p-2">
          <p className="text-textGray text-xs">Most Ordered Item</p>
          <p className="font-medium text-sm text-secondary mt-1">{analytics?.mostOrderedItems?.[0]?.name || 'N/A'}</p>
        </div>
        <div className="w-1/2 md:w-1/4 p-2">
          <p className="text-textGray text-xs">Peak Hour</p>
          <p className="font-medium text-sm text-secondary mt-1">{analytics?.peakHours?.[0]?.hour || 'N/A'}</p>
        </div>
        <div className="w-1/2 md:w-1/4 p-2">
          <p className="text-textGray text-xs">Average Order Value</p>
          <p className="font-medium text-sm text-secondary mt-1">₹{analytics?.averageOrderValue || 0}</p>
        </div>
        <div className="w-1/2 md:w-1/4 p-2">
          <p className="text-textGray text-xs">Returning Customers</p>
          <p className="font-medium text-sm text-secondary mt-1">{analytics?.returningCustomerPercentage || 0}%</p>
        </div>
      </div>
    </div>
  );
};

export default SalesChart;
