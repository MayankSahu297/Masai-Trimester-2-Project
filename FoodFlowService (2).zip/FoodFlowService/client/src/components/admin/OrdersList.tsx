import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

type OrdersListProps = {
  restaurantId: number;
};

const OrdersList = ({ restaurantId }: OrdersListProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  
  // Fetch orders for the restaurant
  const { data: orders, isLoading } = useQuery({
    queryKey: [`/api/orders?restaurantId=${restaurantId}${statusFilter ? `&status=${statusFilter}` : ''}`],
  });
  
  // Fetch detailed order when selected
  const { data: selectedOrder, isLoading: isLoadingOrderDetails } = useQuery({
    queryKey: [`/api/orders/${selectedOrderId}`],
    enabled: !!selectedOrderId,
  });
  
  // Update order status mutation
  const updateStatusMutation = useMutation({
    mutationFn: async ({ orderId, status }: { orderId: number; status: string }) => {
      const res = await apiRequest('PUT', `/api/orders/${orderId}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/orders`] });
      toast({
        title: 'Order Updated',
        description: 'Order status has been updated successfully',
      });
      setIsDetailDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update order status',
        variant: 'destructive',
      });
    },
  });
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };
  
  // Handle view order details
  const handleViewDetails = (orderId: number) => {
    setSelectedOrderId(orderId);
    setIsDetailDialogOpen(true);
  };
  
  // Handle status update
  const handleUpdateStatus = (status: string) => {
    if (!selectedOrderId) return;
    
    updateStatusMutation.mutate({ 
      orderId: selectedOrderId, 
      status 
    });
  };
  
  // Get next status options based on current status
  const getNextStatusOptions = (currentStatus: string) => {
    switch (currentStatus) {
      case 'placed':
        return ['confirmed', 'cancelled'];
      case 'confirmed':
        return ['preparing', 'cancelled'];
      case 'preparing':
        return ['on_the_way', 'cancelled'];
      case 'on_the_way':
        return ['delivered', 'cancelled'];
      case 'delivered':
        return []; // Terminal state
      case 'cancelled':
        return []; // Terminal state
      default:
        return [];
    }
  };
  
  // Status badge color
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'placed':
        return 'bg-amber-100 text-amber-700';
      case 'confirmed':
        return 'bg-amber-100 text-amber-700';
      case 'preparing':
        return 'bg-blue-100 text-blue-700';
      case 'on_the_way':
        return 'bg-blue-100 text-blue-700';
      case 'delivered':
        return 'bg-green-100 text-green-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };
  
  // Format status for display
  const formatStatus = (status: string) => {
    switch (status) {
      case 'placed':
        return 'Order Placed';
      case 'confirmed':
        return 'Confirmed';
      case 'preparing':
        return 'Preparing';
      case 'on_the_way':
        return 'On the Way';
      case 'delivered':
        return 'Delivered';
      case 'cancelled':
        return 'Cancelled';
      default:
        return status;
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
      <h2 className="font-bold text-secondary mb-4">Active Orders</h2>
      
      <div className="mb-4 flex justify-between">
        <div className="flex items-center">
          <span className="mr-2 text-sm">Filter Status:</span>
          <Select
            value={statusFilter || ""}
            onValueChange={(value) => setStatusFilter(value === "" ? null : value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All Orders" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Orders</SelectItem>
              <SelectItem value="placed">Order Placed</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="preparing">Preparing</SelectItem>
              <SelectItem value="on_the_way">On the Way</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {isLoading ? (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-textGray">Loading orders...</p>
        </div>
      ) : orders?.length === 0 ? (
        <div className="text-center py-8">
          <i className="fas fa-receipt text-4xl text-gray-300 mb-2"></i>
          <p className="text-textGray">No orders found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {orders?.map((order: any) => (
            <div key={order.id} className="border border-gray-200 rounded-lg p-3">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-medium text-secondary">#{order.id}</h3>
                  <p className="text-xs text-textGray mt-1">{formatDate(order.placedAt)}</p>
                </div>
                <span className={`${getStatusBadgeClass(order.status)} text-xs px-2 py-1 rounded-full`}>
                  {formatStatus(order.status)}
                </span>
              </div>
              <div className="text-xs text-textGray mb-2">
                {/* Since we don't have items here, show amount */}
                <p>Total Amount: ₹{order.totalAmount}</p>
              </div>
              <div className="flex justify-between items-center mt-3 pt-3 border-t border-gray-100">
                <span className="text-sm font-medium text-secondary">₹{order.totalAmount}</span>
                <div className="flex space-x-2">
                  <Button
                    variant="default"
                    size="sm"
                    className="text-xs bg-blue-600 hover:bg-blue-700"
                    onClick={() => handleViewDetails(order.id)}
                  >
                    Details
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Order Details Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          
          {isLoadingOrderDetails ? (
            <div className="text-center py-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
              <p className="mt-2 text-textGray">Loading order details...</p>
            </div>
          ) : selectedOrder ? (
            <div className="py-4">
              <div className="flex justify-between mb-4">
                <div>
                  <h3 className="font-medium text-secondary">Order #{selectedOrder.id}</h3>
                  <p className="text-xs text-textGray mt-1">{formatDate(selectedOrder.placedAt)}</p>
                </div>
                <span className={`${getStatusBadgeClass(selectedOrder.status)} text-xs px-2 py-1 rounded-full h-fit`}>
                  {formatStatus(selectedOrder.status)}
                </span>
              </div>
              
              <div className="border-t border-gray-200 pt-4 mb-4">
                <h4 className="text-sm font-medium text-secondary mb-2">Order Items</h4>
                {selectedOrder.items.map((item: any) => (
                  <div key={item.id} className="flex justify-between py-2 text-sm">
                    <div>
                      <span className="font-medium">{item.menuItem.name}</span>
                      <span className="text-textGray ml-2">x{item.quantity}</span>
                    </div>
                    <span>₹{item.totalPrice}</span>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-gray-200 pt-4 mb-4">
                <h4 className="text-sm font-medium text-secondary mb-2">Payment Details</h4>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-textGray">Subtotal</span>
                  <span>₹{selectedOrder.totalAmount - selectedOrder.deliveryFee - selectedOrder.tax}</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-textGray">Delivery Fee</span>
                  <span>₹{selectedOrder.deliveryFee}</span>
                </div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-textGray">Tax</span>
                  <span>₹{selectedOrder.tax}</span>
                </div>
                <div className="flex justify-between text-sm font-medium pt-2 border-t border-gray-100 mt-2">
                  <span>Total</span>
                  <span>₹{selectedOrder.totalAmount}</span>
                </div>
              </div>
              
              {getNextStatusOptions(selectedOrder.status).length > 0 && (
                <div className="border-t border-gray-200 pt-4">
                  <h4 className="text-sm font-medium text-secondary mb-2">Update Status</h4>
                  <div className="flex space-x-2">
                    {getNextStatusOptions(selectedOrder.status).map((status) => (
                      <Button
                        key={status}
                        variant={status === 'cancelled' ? 'destructive' : 'default'}
                        size="sm"
                        onClick={() => handleUpdateStatus(status)}
                        disabled={updateStatusMutation.isPending}
                      >
                        {formatStatus(status)}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <p className="text-textGray">Order not found</p>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OrdersList;
