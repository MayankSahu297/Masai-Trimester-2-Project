type StatsCardProps = {
  title: string;
  value: number | string;
  trend: string;
  trendUp?: boolean;
  icon: string;
  iconClass: string;
  isLoading?: boolean;
};

const StatsCard = ({ 
  title, 
  value, 
  trend, 
  trendUp = true, 
  icon, 
  iconClass,
  isLoading = false
}: StatsCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-textGray text-sm">{title}</p>
          {isLoading ? (
            <div className="h-8 w-24 bg-gray-200 animate-pulse rounded mt-1"></div>
          ) : (
            <h2 className="text-2xl font-bold text-secondary mt-1">{value}</h2>
          )}
          <p className={`text-xs mt-1 ${trendUp ? 'text-success' : 'text-textGray'}`}>{trend}</p>
        </div>
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${iconClass}`}>
          <i className={icon}></i>
        </div>
      </div>
    </div>
  );
};

export default StatsCard;
