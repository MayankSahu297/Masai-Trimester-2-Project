import { useState } from 'react';
import { FilterOptions } from '@shared/types';

type FiltersProps = {
  onFilterChange: (filters: FilterOptions) => void;
  currentFilters: FilterOptions;
};

const Filters = ({ onFilterChange, currentFilters }: FiltersProps) => {
  const handleSortChange = () => {
    // Toggle between sorting by rating (default), delivery time, and price
    const nextSort = !currentFilters.sortBy 
      ? 'rating' 
      : currentFilters.sortBy === 'rating' 
        ? 'deliveryTime' 
        : currentFilters.sortBy === 'deliveryTime' 
          ? 'priceForTwo' 
          : undefined;
          
    onFilterChange({
      ...currentFilters,
      sortBy: nextSort as any,
    });
  };
  
  const toggleFilter = (filterType: string, value: any) => {
    switch (filterType) {
      case 'fastDelivery':
        onFilterChange({
          ...currentFilters,
          filters: {
            ...currentFilters.filters,
            maxDeliveryTime: currentFilters.filters.maxDeliveryTime === 30 ? undefined : 30,
          },
        });
        break;
      case 'veg':
        onFilterChange({
          ...currentFilters,
          filters: {
            ...currentFilters.filters,
            veg: !currentFilters.filters.veg,
          },
        });
        break;
      case 'ratings':
        // Toggle ratings filter (4.0+)
        onFilterChange({
          ...currentFilters,
          filters: {
            ...currentFilters.filters,
            // This would be implemented differently in a real application
            // with more granular rating filters
          },
        });
        break;
      case 'priceRange':
        onFilterChange({
          ...currentFilters,
          filters: {
            ...currentFilters.filters,
            priceRange: currentFilters.filters.priceRange ? undefined : [300, 600],
          },
        });
        break;
      default:
        break;
    }
  };
  
  // Helper to check if a filter is active
  const isFilterActive = (filterType: string): boolean => {
    switch (filterType) {
      case 'sort':
        return !!currentFilters.sortBy;
      case 'fastDelivery':
        return currentFilters.filters.maxDeliveryTime === 30;
      case 'veg':
        return !!currentFilters.filters.veg;
      case 'priceRange':
        return !!currentFilters.filters.priceRange;
      default:
        return false;
    }
  };
  
  return (
    <div className="bg-white py-4 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex flex-nowrap overflow-x-auto hide-scrollbar gap-3 pb-2">
          <button 
            className={`whitespace-nowrap px-3 py-1.5 text-sm border rounded-full flex-shrink-0 
              ${isFilterActive('sort') 
                ? 'border-primary bg-orange-50 text-primary' 
                : 'border-gray-300 bg-white hover:bg-gray-50 text-textGray'}`}
            onClick={handleSortChange}
          >
            <i className="fas fa-sort mr-2 text-textGray"></i> Sort
          </button>
          
          <button 
            className={`whitespace-nowrap px-3 py-1.5 text-sm border rounded-full flex-shrink-0
              ${isFilterActive('fastDelivery') 
                ? 'border-primary bg-orange-50 text-primary' 
                : 'border-gray-300 bg-white hover:bg-gray-50 text-textGray'}`}
            onClick={() => toggleFilter('fastDelivery', null)}
          >
            Fast Delivery
          </button>
          
          <button className="whitespace-nowrap px-3 py-1.5 text-sm border border-gray-300 rounded-full bg-white hover:bg-gray-50 flex-shrink-0 text-textGray">
            New on FoodHub
          </button>
          
          <button className="whitespace-nowrap px-3 py-1.5 text-sm border border-gray-300 rounded-full bg-white hover:bg-gray-50 flex-shrink-0 text-textGray">
            Ratings 4.0+
          </button>
          
          <button 
            className={`whitespace-nowrap px-3 py-1.5 text-sm border rounded-full flex-shrink-0
              ${isFilterActive('veg') 
                ? 'border-primary bg-orange-50 text-primary' 
                : 'border-gray-300 bg-white hover:bg-gray-50 text-textGray'}`}
            onClick={() => toggleFilter('veg', null)}
          >
            Pure Veg
          </button>
          
          <button 
            className={`whitespace-nowrap px-3 py-1.5 text-sm border rounded-full flex-shrink-0
              ${isFilterActive('priceRange') 
                ? 'border-primary bg-orange-50 text-primary' 
                : 'border-gray-300 bg-white hover:bg-gray-50 text-textGray'}`}
            onClick={() => toggleFilter('priceRange', null)}
          >
            Price: ₹300-₹600
          </button>
          
          <button className="whitespace-nowrap px-3 py-1.5 text-sm border border-gray-300 rounded-full bg-white hover:bg-gray-50 flex-shrink-0 text-textGray">
            Less than 30 min
          </button>
        </div>
      </div>
    </div>
  );
};

export default Filters;
