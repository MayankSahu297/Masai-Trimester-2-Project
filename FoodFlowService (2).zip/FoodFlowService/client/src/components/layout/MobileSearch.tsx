import { useState } from 'react';
import { useLocation } from 'wouter';

const MobileSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [location, navigate] = useLocation();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/?search=${encodeURIComponent(searchTerm)}`);
    }
  };
  
  return (
    <div className="bg-white py-3 md:hidden px-4">
      <form onSubmit={handleSearch}>
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search restaurants and food" 
            className="w-full py-2 px-4 pl-10 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary text-sm"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            <i className="fas fa-search"></i>
          </div>
        </div>
      </form>
    </div>
  );
};

export default MobileSearch;
