import { useState } from 'react';
import { useCart } from '@/hooks/use-cart';
import { MenuItem as MenuItemType, Restaurant } from '@shared/schema';
import { Button } from '@/components/ui/button';

type MenuItemProps = {
  menuItem: MenuItemType;
  restaurant: Restaurant;
};

const MenuItem = ({ menuItem, restaurant }: MenuItemProps) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  
  const handleAddToCart = () => {
    addToCart(restaurant, menuItem, quantity);
    setQuantity(1); // Reset quantity after adding
  };
  
  return (
    <div className="flex justify-between items-center border-b border-gray-100 py-4">
      <div className="flex-1 pr-4">
        <div className="flex items-center">
          <span className={`w-5 h-5 flex items-center justify-center border text-xs mr-2 ${
            menuItem.isVeg 
              ? 'border-success text-success' 
              : 'border-red-500 text-red-500'
          }`}>
            <i className="fas fa-circle"></i>
          </span>
          <h3 className="font-medium text-secondary">{menuItem.name}</h3>
        </div>
        <p className="text-sm text-textGray mt-1">₹{menuItem.price}</p>
        <p className="text-xs text-textGray mt-2">{menuItem.description}</p>
        {!menuItem.inStock && (
          <p className="text-xs text-red-500 mt-1">Out of stock</p>
        )}
      </div>
      <div className="relative min-w-[118px] h-[96px]">
        {menuItem.imageUrl ? (
          <img 
            src={menuItem.imageUrl} 
            alt={menuItem.name} 
            className="w-[118px] h-[96px] rounded-lg object-cover"
          />
        ) : (
          <div className="w-[118px] h-[96px] rounded-lg bg-gray-200 flex items-center justify-center">
            <i className="fas fa-utensils text-gray-400 text-2xl"></i>
          </div>
        )}
        
        {menuItem.inStock ? (
          <Button
            onClick={handleAddToCart}
            size="sm"
            className="absolute bottom-2 right-2 bg-white text-success border border-gray-300 font-medium text-sm px-4 py-1 rounded shadow-sm hover:bg-gray-50"
          >
            ADD
          </Button>
        ) : (
          <span className="absolute bottom-2 right-2 bg-gray-200 text-gray-500 font-medium text-sm px-4 py-1 rounded">
            SOLD OUT
          </span>
        )}
      </div>
    </div>
  );
};

export default MenuItem;
