import { MenuItem, Restaurant, Order, OrderItem } from './schema';

// Types for frontend data handling

export type CartItemType = {
  menuItem: MenuItem;
  quantity: number;
  specialInstructions?: string;
  customizations?: Record<string, any>;
};

export type CartType = {
  restaurant: Restaurant | null;
  items: CartItemType[];
  deliveryFee: number;
  tax: number;
};

export type OrderWithItems = Order & {
  items: (OrderItem & { menuItem: MenuItem })[];
  restaurant: Restaurant;
};

export type FilterOptions = {
  sortBy?: 'rating' | 'deliveryTime' | 'priceForTwo';
  filters: {
    cuisine?: string[];
    veg?: boolean;
    maxDeliveryTime?: number;
    priceRange?: [number, number];
  };
};

export type StatusUpdate = {
  orderId: number;
  newStatus: 'placed' | 'confirmed' | 'preparing' | 'on_the_way' | 'delivered' | 'cancelled';
  timestamp: Date;
};

export type AnalyticsData = {
  totalOrders: number;
  revenue: number;
  pendingOrders: number;
  mostOrderedItems: { name: string; count: number }[];
  peakHours: { hour: string; orders: number }[];
  ordersByCategory: { category: string; revenue: number }[];
  averageOrderValue: number;
  returningCustomerPercentage: number;
};
