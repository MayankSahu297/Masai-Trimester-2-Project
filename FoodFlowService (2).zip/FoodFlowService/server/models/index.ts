import mongoose from 'mongoose';
import { 
  Restaurant, 
  MenuItem,
  Order, 
  OrderItem, 
  User,
  Cart
} from '@shared/schema';

// Connect to MongoDB
export const connectToDatabase = async () => {
  try {
    // Check for valid MONGODB_URI
    const mongoUri = process.env.MONGODB_URI;
    
    if (!mongoUri) {
      console.log('No MONGODB_URI provided, using in-memory storage');
      return false;
    }
    
    // Validate URI format
    if (!(mongoUri.startsWith('mongodb://') || mongoUri.startsWith('mongodb+srv://'))) {
      console.error('Invalid MongoDB URI format');
      return false;
    }
    
    // Connect with proper options
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 5000, // Timeout after 5 seconds
      socketTimeoutMS: 45000, // Close sockets after 45 seconds of inactivity
    });
    
    console.log('Connected to MongoDB successfully');
    return true;
  } catch (error) {
    console.error('MongoDB connection error:', error);
    console.log('Using in-memory storage instead');
    return false;
  }
};

// Restaurant Schema
const restaurantSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  cuisineTypes: { type: [String], required: true },
  rating: { type: Number, default: null },
  deliveryTime: { type: Number, required: true },
  priceForTwo: { type: Number, required: true },
  imageUrl: { type: String, required: true },
  offers: { type: [String], default: [] },
  isOpen: { type: Boolean, default: true }
}, { timestamps: true });

// Menu Item Schema
const menuItemSchema = new mongoose.Schema({
  restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  category: { type: String, required: true },
  imageUrl: { type: String, default: null },
  isVeg: { type: Boolean, required: true },
  inStock: { type: Boolean, default: true },
  tags: { type: [String], default: [] },
  ingredients: { type: [String], default: [] }
}, { timestamps: true });

// Create indexes for menu item search optimization
menuItemSchema.index({ name: 'text', description: 'text', tags: 'text', ingredients: 'text' });
menuItemSchema.index({ restaurantId: 1 });
menuItemSchema.index({ category: 1 });
menuItemSchema.index({ isVeg: 1 });
menuItemSchema.index({ price: 1 });

// Order Item Schema
const orderItemSchema = new mongoose.Schema({
  orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  menuItemId: { type: mongoose.Schema.Types.ObjectId, ref: 'MenuItem', required: true },
  quantity: { type: Number, required: true },
  unitPrice: { type: Number, required: true },
  totalPrice: { type: Number, required: true },
  specialInstructions: { type: String, default: null },
  customizations: { type: Map, of: mongoose.Schema.Types.Mixed, default: {} }
});

// Order Schema
const orderSchema = new mongoose.Schema({
  restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  status: { 
    type: String, 
    required: true,
    enum: ['placed', 'confirmed', 'preparing', 'on_the_way', 'delivered', 'cancelled'],
    default: 'placed'
  },
  totalAmount: { type: Number, required: true },
  deliveryFee: { type: Number, required: true },
  tax: { type: Number, required: true },
  paymentMethod: { type: String, required: true },
  deliveryAddress: { type: String, default: null },
  placedAt: { type: Date, default: Date.now },
  estimatedDeliveryTime: { type: Number, default: null },
  specialInstructions: { type: String, default: null },
  statusHistory: { 
    type: [{ 
      status: String, 
      timestamp: { type: Date, default: Date.now } 
    }], 
    default: [] 
  }
}, { timestamps: true });

// Create indexes for order lookup optimization
orderSchema.index({ restaurantId: 1 });
orderSchema.index({ customerId: 1 });
orderSchema.index({ status: 1 });
orderSchema.index({ placedAt: 1 });

// User Schema
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, default: null },
  role: { type: String, default: 'customer', enum: ['customer', 'admin'] },
  addresses: { type: [Object], default: [] }
}, { timestamps: true });

// Cart Schema
const cartSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  restaurantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Restaurant', required: true },
  items: { type: Array, default: [] }
}, { timestamps: true });

// Define models
export const RestaurantModel = mongoose.model('Restaurant', restaurantSchema);
export const MenuItemModel = mongoose.model('MenuItem', menuItemSchema);
export const OrderModel = mongoose.model('Order', orderSchema);
export const OrderItemModel = mongoose.model('OrderItem', orderItemSchema);
export const UserModel = mongoose.model('User', userSchema);
export const CartModel = mongoose.model('Cart', cartSchema);