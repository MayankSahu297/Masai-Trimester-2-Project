import { 
  Restaurant, InsertRestaurant, 
  MenuItem, InsertMenuItem, 
  Order, InsertOrder, 
  OrderItem, InsertOrderItem,
  User, InsertUser,
  Cart, InsertCart
} from '@shared/schema';
import { OrderWithItems, StatusUpdate, AnalyticsData, FilterOptions } from '@shared/types';

// Interface for restaurant management
export interface IRestaurantStorage {
  // Restaurant operations
  getRestaurants(filters?: FilterOptions): Promise<Restaurant[]>;
  getRestaurantById(id: number): Promise<Restaurant | undefined>;
  createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant>;
  updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant | undefined>;
  deleteRestaurant(id: number): Promise<boolean>;
  
  // Menu operations
  getMenuItems(restaurantId: number, category?: string): Promise<MenuItem[]>;
  getMenuItemById(id: number): Promise<MenuItem | undefined>;
  createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: number, menuItem: Partial<InsertMenuItem>): Promise<MenuItem | undefined>;
  deleteMenuItem(id: number): Promise<boolean>;
  searchMenuItems(
    restaurantId: number, 
    search: string, 
    filters?: { category?: string, isVeg?: boolean, priceRange?: [number, number], tags?: string[] }
  ): Promise<MenuItem[]>;
  
  // Order operations
  getOrders(restaurantId?: number, customerId?: number, status?: string): Promise<Order[]>;
  getOrderById(id: number): Promise<OrderWithItems | undefined>;
  createOrder(order: InsertOrder, orderItems: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(statusUpdate: StatusUpdate): Promise<Order | undefined>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Cart operations
  getCart(userId?: number): Promise<Cart | undefined>;
  createOrUpdateCart(cart: InsertCart): Promise<Cart>;
  
  // Analytics operations
  getAnalytics(restaurantId: number, startDate?: Date, endDate?: Date): Promise<AnalyticsData>;
}

// Memory storage implementation
export class MemStorage implements IRestaurantStorage {
  private restaurants: Map<number, Restaurant>;
  private menuItems: Map<number, MenuItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem[]>;
  private users: Map<number, User>;
  private carts: Map<number, Cart>;
  
  private currentRestaurantId: number;
  private currentMenuItemId: number;
  private currentOrderId: number;
  private currentOrderItemId: number;
  private currentUserId: number;
  private currentCartId: number;
  
  constructor() {
    this.restaurants = new Map();
    this.menuItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.users = new Map();
    this.carts = new Map();
    
    this.currentRestaurantId = 1;
    this.currentMenuItemId = 1;
    this.currentOrderId = 1;
    this.currentOrderItemId = 1;
    this.currentUserId = 1;
    this.currentCartId = 1;
    
    // Initialize with some sample data
    this.initializeData();
  }
  
  private initializeData() {
    // Create sample restaurants
    const restaurant1: InsertRestaurant = {
      name: "Spice Paradise",
      description: "Authentic North Indian cuisine",
      cuisineTypes: ["North Indian", "Chinese", "Biryani"],
      rating: 4.2,
      deliveryTime: 28,
      priceForTwo: 200,
      imageUrl: "https://images.unsplash.com/photo-1585937421612-70a008356fbe",
      offers: ["50% off up to ₹100"],
      isOpen: true
    };
    
    const restaurant2: InsertRestaurant = {
      name: "Pasta Palace",
      description: "Italian restaurant with authentic pasta dishes",
      cuisineTypes: ["Italian", "Continental", "Pasta"],
      rating: 4.5,
      deliveryTime: 35,
      priceForTwo: 350,
      imageUrl: "https://images.unsplash.com/photo-1579684947550-22e945225d9a",
      offers: ["Free delivery on orders above ₹299"],
      isOpen: true
    };
    
    const restaurant3: InsertRestaurant = {
      name: "Sushi Express",
      description: "Japanese sushi and Asian cuisine",
      cuisineTypes: ["Japanese", "Asian", "Sushi"],
      rating: 4.3,
      deliveryTime: 40,
      priceForTwo: 450,
      imageUrl: "https://pixabay.com/get/g925a6790c414dd145e6fde2ca000c62409c06873e7066c230b5fd40ffbd594c5b834b9333f24bebb0bb67d67455faabeb0e1e70824c4c5ae35fa1f5ea56e2e43_1280.jpg",
      offers: ["20% off on all sushi platters"],
      isOpen: true
    };
    
    const r1 = this.createRestaurant(restaurant1);
    const r2 = this.createRestaurant(restaurant2);
    const r3 = this.createRestaurant(restaurant3);
    
    // Create sample menu items for Spice Paradise
    const menuItems1: InsertMenuItem[] = [
      {
        restaurantId: r1.id,
        name: "Butter Chicken",
        description: "Tender chicken cooked in rich tomato and butter gravy",
        price: 290,
        category: "Main Course",
        imageUrl: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398",
        isVeg: false,
        inStock: true,
        tags: ["popular", "spicy"],
        ingredients: ["chicken", "tomato", "butter", "cream", "spices"]
      },
      {
        restaurantId: r1.id,
        name: "Paneer Tikka Masala",
        description: "Grilled cottage cheese cubes in spiced tomato gravy",
        price: 260,
        category: "Main Course",
        imageUrl: "https://images.unsplash.com/photo-1565557623262-b51c2513a641",
        isVeg: true,
        inStock: true,
        tags: ["popular", "spicy", "vegetarian"],
        ingredients: ["paneer", "tomato", "bell peppers", "spices"]
      },
      {
        restaurantId: r1.id,
        name: "Chicken Biryani",
        description: "Fragrant basmati rice cooked with chicken, spices and herbs",
        price: 320,
        category: "Biryani",
        imageUrl: "https://images.unsplash.com/photo-1589302168068-964664d93dc0",
        isVeg: false,
        inStock: false,
        tags: ["popular", "spicy"],
        ingredients: ["chicken", "basmati rice", "spices", "herbs", "fried onions"]
      },
      {
        restaurantId: r1.id,
        name: "Garlic Naan",
        description: "Flatbread topped with garlic and butter",
        price: 60,
        category: "Breads",
        imageUrl: "https://pixabay.com/get/g69eb43fd028729c3a08835e17574028f644befbb34b9acccef9672052e4fe1604e9eabda833e081465d0b7bca0dd66df20b8d61f480fa41c494b170d249ba6cc_1280.jpg",
        isVeg: true,
        inStock: true,
        tags: ["vegetarian"],
        ingredients: ["flour", "garlic", "butter"]
      }
    ];
    
    menuItems1.forEach(item => this.createMenuItem(item));
    
    // Create some users
    const admin: InsertUser = {
      username: "admin",
      password: "password", // In real app, this would be hashed
      name: "Admin User",
      email: "admin@example.com",
      phone: "1234567890",
      role: "admin"
    };
    
    const customer: InsertUser = {
      username: "customer",
      password: "password", // In real app, this would be hashed
      name: "Test Customer",
      email: "customer@example.com",
      phone: "9876543210",
      role: "customer"
    };
    
    this.createUser(admin);
    this.createUser(customer);
  }
  
  // Restaurant operations
  async getRestaurants(filters?: FilterOptions): Promise<Restaurant[]> {
    let restaurants = Array.from(this.restaurants.values());
    
    if (filters) {
      // Filter by cuisine if provided
      if (filters.filters.cuisine && filters.filters.cuisine.length > 0) {
        restaurants = restaurants.filter(r => 
          r.cuisineTypes.some(cuisine => filters.filters.cuisine?.includes(cuisine))
        );
      }
      
      // Filter by veg if provided
      if (filters.filters.veg) {
        // For a restaurant to be veg, we need to check if all its menu items are veg
        // This is a simplified approach for the memory storage
        restaurants = restaurants.filter(r => {
          const menuItemsForRestaurant = Array.from(this.menuItems.values())
            .filter(m => m.restaurantId === r.id);
          return menuItemsForRestaurant.every(m => m.isVeg);
        });
      }
      
      // Filter by max delivery time if provided
      if (filters.filters.maxDeliveryTime) {
        restaurants = restaurants.filter(r => 
          r.deliveryTime <= (filters.filters.maxDeliveryTime || Infinity)
        );
      }
      
      // Filter by price range if provided
      if (filters.filters.priceRange) {
        const [min, max] = filters.filters.priceRange;
        restaurants = restaurants.filter(r => 
          r.priceForTwo >= min && r.priceForTwo <= max
        );
      }
      
      // Sort results if sortBy is provided
      if (filters.sortBy) {
        restaurants.sort((a, b) => {
          switch (filters.sortBy) {
            case 'rating':
              return (b.rating || 0) - (a.rating || 0);
            case 'deliveryTime':
              return a.deliveryTime - b.deliveryTime;
            case 'priceForTwo':
              return a.priceForTwo - b.priceForTwo;
            default:
              return 0;
          }
        });
      }
    }
    
    return restaurants;
  }
  
  async getRestaurantById(id: number): Promise<Restaurant | undefined> {
    return this.restaurants.get(id);
  }
  
  async createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant> {
    const id = this.currentRestaurantId++;
    const newRestaurant: Restaurant = { ...restaurant, id };
    this.restaurants.set(id, newRestaurant);
    return newRestaurant;
  }
  
  async updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant | undefined> {
    const existingRestaurant = this.restaurants.get(id);
    if (!existingRestaurant) {
      return undefined;
    }
    
    const updatedRestaurant = { ...existingRestaurant, ...restaurant };
    this.restaurants.set(id, updatedRestaurant);
    return updatedRestaurant;
  }
  
  async deleteRestaurant(id: number): Promise<boolean> {
    return this.restaurants.delete(id);
  }
  
  // Menu operations
  async getMenuItems(restaurantId: number, category?: string): Promise<MenuItem[]> {
    let menuItems = Array.from(this.menuItems.values())
      .filter(item => item.restaurantId === restaurantId);
      
    if (category) {
      menuItems = menuItems.filter(item => item.category === category);
    }
    
    return menuItems;
  }
  
  async getMenuItemById(id: number): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }
  
  async createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem> {
    const id = this.currentMenuItemId++;
    const newMenuItem: MenuItem = { ...menuItem, id };
    this.menuItems.set(id, newMenuItem);
    return newMenuItem;
  }
  
  async updateMenuItem(id: number, menuItem: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    const existingMenuItem = this.menuItems.get(id);
    if (!existingMenuItem) {
      return undefined;
    }
    
    const updatedMenuItem = { ...existingMenuItem, ...menuItem };
    this.menuItems.set(id, updatedMenuItem);
    return updatedMenuItem;
  }
  
  async deleteMenuItem(id: number): Promise<boolean> {
    return this.menuItems.delete(id);
  }
  
  async searchMenuItems(
    restaurantId: number,
    search: string,
    filters?: { category?: string, isVeg?: boolean, priceRange?: [number, number], tags?: string[] }
  ): Promise<MenuItem[]> {
    let menuItems = Array.from(this.menuItems.values())
      .filter(item => item.restaurantId === restaurantId);
    
    // Search by name, description, or ingredients
    if (search) {
      const searchLower = search.toLowerCase();
      menuItems = menuItems.filter(item => 
        item.name.toLowerCase().includes(searchLower) ||
        item.description.toLowerCase().includes(searchLower) ||
        item.ingredients?.some(ingredient => ingredient.toLowerCase().includes(searchLower))
      );
    }
    
    // Apply filters
    if (filters) {
      if (filters.category) {
        menuItems = menuItems.filter(item => item.category === filters.category);
      }
      
      if (filters.isVeg !== undefined) {
        menuItems = menuItems.filter(item => item.isVeg === filters.isVeg);
      }
      
      if (filters.priceRange) {
        const [min, max] = filters.priceRange;
        menuItems = menuItems.filter(item => item.price >= min && item.price <= max);
      }
      
      if (filters.tags && filters.tags.length > 0) {
        menuItems = menuItems.filter(item => 
          item.tags?.some(tag => filters.tags?.includes(tag))
        );
      }
    }
    
    return menuItems;
  }
  
  // Order operations
  async getOrders(restaurantId?: number, customerId?: number, status?: string): Promise<Order[]> {
    let orders = Array.from(this.orders.values());
    
    if (restaurantId !== undefined) {
      orders = orders.filter(order => order.restaurantId === restaurantId);
    }
    
    if (customerId !== undefined) {
      orders = orders.filter(order => order.customerId === customerId);
    }
    
    if (status) {
      orders = orders.filter(order => order.status === status);
    }
    
    // Sort by placedAt time, newest first
    orders.sort((a, b) => {
      return new Date(b.placedAt).getTime() - new Date(a.placedAt).getTime();
    });
    
    return orders;
  }
  
  async getOrderById(id: number): Promise<OrderWithItems | undefined> {
    const order = this.orders.get(id);
    if (!order) {
      return undefined;
    }
    
    const orderItems = this.orderItems.get(id) || [];
    const restaurant = this.restaurants.get(order.restaurantId);
    
    if (!restaurant) {
      return undefined;
    }
    
    const itemsWithDetails = orderItems.map(item => {
      const menuItem = this.menuItems.get(item.menuItemId);
      return {
        ...item,
        menuItem: menuItem!
      };
    });
    
    return {
      ...order,
      items: itemsWithDetails,
      restaurant
    };
  }
  
  async createOrder(order: InsertOrder, orderItems: InsertOrderItem[]): Promise<Order> {
    const id = this.currentOrderId++;
    
    const newOrder: Order = {
      ...order,
      id,
      placedAt: new Date(),
      statusHistory: [{ status: order.status, timestamp: new Date() }]
    };
    
    this.orders.set(id, newOrder);
    
    // Process order items
    const processedItems = orderItems.map(item => {
      const itemId = this.currentOrderItemId++;
      return { ...item, id, orderId: id };
    });
    
    this.orderItems.set(id, processedItems);
    
    return newOrder;
  }
  
  async updateOrderStatus(statusUpdate: StatusUpdate): Promise<Order | undefined> {
    const order = this.orders.get(statusUpdate.orderId);
    if (!order) {
      return undefined;
    }
    
    const updatedOrder: Order = {
      ...order,
      status: statusUpdate.newStatus,
      statusHistory: [
        ...order.statusHistory as any[],
        { status: statusUpdate.newStatus, timestamp: statusUpdate.timestamp }
      ]
    };
    
    this.orders.set(statusUpdate.orderId, updatedOrder);
    return updatedOrder;
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const newUser: User = { ...user, id, addresses: [] };
    this.users.set(id, newUser);
    return newUser;
  }
  
  // Cart operations
  async getCart(userId?: number): Promise<Cart | undefined> {
    if (userId) {
      return Array.from(this.carts.values()).find(cart => cart.userId === userId);
    }
    return undefined;
  }
  
  async createOrUpdateCart(cart: InsertCart): Promise<Cart> {
    // Check if cart exists for this user
    if (cart.userId) {
      const existingCart = await this.getCart(cart.userId);
      if (existingCart) {
        const updatedCart: Cart = {
          ...existingCart,
          ...cart,
          updatedAt: new Date()
        };
        this.carts.set(existingCart.id, updatedCart);
        return updatedCart;
      }
    }
    
    // Create new cart
    const id = this.currentCartId++;
    const newCart: Cart = {
      ...cart,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.carts.set(id, newCart);
    return newCart;
  }
  
  // Analytics operations
  async getAnalytics(restaurantId: number, startDate?: Date, endDate?: Date): Promise<AnalyticsData> {
    const now = new Date();
    const defaultStartDate = new Date(now);
    defaultStartDate.setDate(now.getDate() - 30); // Default to last 30 days
    
    const start = startDate || defaultStartDate;
    const end = endDate || now;
    
    // Get all orders for this restaurant within the date range
    const allOrders = Array.from(this.orders.values()).filter(order => 
      order.restaurantId === restaurantId &&
      new Date(order.placedAt) >= start &&
      new Date(order.placedAt) <= end
    );
    
    // Calculate analytics
    const totalOrders = allOrders.length;
    
    // Sum up revenue
    const revenue = allOrders.reduce((sum, order) => sum + order.totalAmount, 0);
    
    // Count pending orders (not delivered or cancelled)
    const pendingOrders = allOrders.filter(order => 
      !['delivered', 'cancelled'].includes(order.status)
    ).length;
    
    // Analyze order items
    const orderItemsMap = new Map<number, number>(); // menuItemId -> count
    
    for (const order of allOrders) {
      const items = this.orderItems.get(order.id) || [];
      for (const item of items) {
        const count = orderItemsMap.get(item.menuItemId) || 0;
        orderItemsMap.set(item.menuItemId, count + item.quantity);
      }
    }
    
    // Get most ordered items
    const sortedItems = Array.from(orderItemsMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([menuItemId, count]) => {
        const item = this.menuItems.get(menuItemId);
        return { name: item?.name || 'Unknown Item', count };
      });
    
    // Analyze by hour
    const hourCounts = new Map<number, number>();
    for (const order of allOrders) {
      const date = new Date(order.placedAt);
      const hour = date.getHours();
      const count = hourCounts.get(hour) || 0;
      hourCounts.set(hour, count + 1);
    }
    
    const peakHours = Array.from(hourCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([hour, orders]) => {
        const hourStr = `${hour % 12 || 12}${hour < 12 ? 'AM' : 'PM'}`;
        return { hour: hourStr, orders };
      });
    
    // Analyze by category
    const categoryRevenue = new Map<string, number>();
    
    for (const order of allOrders) {
      const orderItems = this.orderItems.get(order.id) || [];
      for (const item of orderItems) {
        const menuItem = this.menuItems.get(item.menuItemId);
        if (menuItem) {
          const category = menuItem.category;
          const rev = categoryRevenue.get(category) || 0;
          categoryRevenue.set(category, rev + item.totalPrice);
        }
      }
    }
    
    const ordersByCategory = Array.from(categoryRevenue.entries())
      .map(([category, revenue]) => ({ category, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
    
    // Average order value
    const averageOrderValue = totalOrders > 0 ? Math.round(revenue / totalOrders) : 0;
    
    // For simplicity in the memory implementation, we'll use a fixed value for returning customers
    const returningCustomerPercentage = 68;
    
    return {
      totalOrders,
      revenue,
      pendingOrders,
      mostOrderedItems: sortedItems,
      peakHours,
      ordersByCategory,
      averageOrderValue,
      returningCustomerPercentage
    };
  }
}

export const storage = new MemStorage();
