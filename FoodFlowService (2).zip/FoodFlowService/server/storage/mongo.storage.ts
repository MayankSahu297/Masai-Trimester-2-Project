import { 
  IRestaurantStorage,
  InsertRestaurant, Restaurant,
  InsertMenuItem, MenuItem,
  InsertOrder, Order, OrderWithItems,
  InsertOrderItem, OrderItem,
  InsertUser, User,
  InsertCart, Cart
} from '@shared/schema';
import { FilterOptions, StatusUpdate, AnalyticsData } from '@shared/types';
import { 
  RestaurantModel, 
  MenuItemModel, 
  OrderModel, 
  OrderItemModel,
  UserModel,
  CartModel
} from '../models';
import mongoose, { Types } from 'mongoose';

export class MongoStorage implements IRestaurantStorage {
  // Restaurant operations
  async getRestaurants(filters?: FilterOptions): Promise<Restaurant[]> {
    let query: any = {};
    
    if (filters) {
      // Filter by cuisine if provided
      if (filters.filters.cuisine && filters.filters.cuisine.length > 0) {
        query.cuisineTypes = { $in: filters.filters.cuisine };
      }
      
      // Filter by veg if provided (need to check menu items)
      if (filters.filters.veg) {
        // Find restaurants with only veg menu items
        const restaurantIds = await MenuItemModel.distinct('restaurantId', { isVeg: true });
        const nonVegRestaurantIds = await MenuItemModel.distinct('restaurantId', { isVeg: false });
        
        // Only include restaurants that have veg items but no non-veg items
        const vegOnlyRestaurantIds = restaurantIds.filter(
          id => !nonVegRestaurantIds.includes(id.toString())
        );
        
        query._id = { $in: vegOnlyRestaurantIds };
      }
      
      // Filter by max delivery time if provided
      if (filters.filters.maxDeliveryTime) {
        query.deliveryTime = { $lte: filters.filters.maxDeliveryTime };
      }
      
      // Filter by price range if provided
      if (filters.filters.priceRange) {
        const [min, max] = filters.filters.priceRange;
        query.priceForTwo = { $gte: min, $lte: max };
      }
    }
    
    let restaurants = await RestaurantModel.find(query);
    
    // Sort results if sortBy is provided
    if (filters?.sortBy) {
      switch (filters.sortBy) {
        case 'rating':
          restaurants.sort((a, b) => (b.rating || 0) - (a.rating || 0));
          break;
        case 'deliveryTime':
          restaurants.sort((a, b) => a.deliveryTime - b.deliveryTime);
          break;
        case 'priceForTwo':
          restaurants.sort((a, b) => a.priceForTwo - b.priceForTwo);
          break;
      }
    }
    
    // Convert to the correct type format
    return restaurants.map(restaurant => this.mapRestaurantToSchema(restaurant));
  }
  
  async getRestaurantById(id: number): Promise<Restaurant | undefined> {
    try {
      const restaurant = await RestaurantModel.findById(id);
      return restaurant ? this.mapRestaurantToSchema(restaurant) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant> {
    const newRestaurant = await RestaurantModel.create(restaurant);
    return this.mapRestaurantToSchema(newRestaurant);
  }
  
  async updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant | undefined> {
    try {
      const updatedRestaurant = await RestaurantModel.findByIdAndUpdate(
        id,
        { $set: restaurant },
        { new: true }
      );
      return updatedRestaurant ? this.mapRestaurantToSchema(updatedRestaurant) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async deleteRestaurant(id: number): Promise<boolean> {
    try {
      const result = await RestaurantModel.findByIdAndDelete(id);
      return !!result;
    } catch (error) {
      return false;
    }
  }
  
  // Menu operations
  async getMenuItems(restaurantId: number, category?: string): Promise<MenuItem[]> {
    const query: any = { restaurantId };
    
    if (category) {
      query.category = category;
    }
    
    const menuItems = await MenuItemModel.find(query);
    return menuItems.map(item => this.mapMenuItemToSchema(item));
  }
  
  async getMenuItemById(id: number): Promise<MenuItem | undefined> {
    try {
      const menuItem = await MenuItemModel.findById(id);
      return menuItem ? this.mapMenuItemToSchema(menuItem) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem> {
    const newMenuItem = await MenuItemModel.create(menuItem);
    return this.mapMenuItemToSchema(newMenuItem);
  }
  
  async updateMenuItem(id: number, menuItem: Partial<InsertMenuItem>): Promise<MenuItem | undefined> {
    try {
      const updatedMenuItem = await MenuItemModel.findByIdAndUpdate(
        id,
        { $set: menuItem },
        { new: true }
      );
      return updatedMenuItem ? this.mapMenuItemToSchema(updatedMenuItem) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async deleteMenuItem(id: number): Promise<boolean> {
    try {
      const result = await MenuItemModel.findByIdAndDelete(id);
      return !!result;
    } catch (error) {
      return false;
    }
  }
  
  async searchMenuItems(
    restaurantId: number,
    search: string,
    filters?: { category?: string, isVeg?: boolean, priceRange?: [number, number], tags?: string[] }
  ): Promise<MenuItem[]> {
    const query: any = { restaurantId };
    
    // Text search
    if (search && search.trim()) {
      query.$text = { $search: search };
    }
    
    // Apply filters
    if (filters) {
      if (filters.category) {
        query.category = filters.category;
      }
      
      if (filters.isVeg !== undefined) {
        query.isVeg = filters.isVeg;
      }
      
      if (filters.priceRange) {
        const [min, max] = filters.priceRange;
        query.price = { $gte: min, $lte: max };
      }
      
      if (filters.tags && filters.tags.length > 0) {
        query.tags = { $in: filters.tags };
      }
    }
    
    const menuItems = await MenuItemModel.find(query);
    return menuItems.map(item => this.mapMenuItemToSchema(item));
  }
  
  // Order operations
  async getOrders(restaurantId?: number, customerId?: number, status?: string): Promise<Order[]> {
    const query: any = {};
    
    if (restaurantId !== undefined) {
      query.restaurantId = restaurantId;
    }
    
    if (customerId !== undefined) {
      query.customerId = customerId;
    }
    
    if (status) {
      query.status = status;
    }
    
    // Sort by placedAt descending (newest first)
    const orders = await OrderModel.find(query).sort({ placedAt: -1 });
    return orders.map(order => this.mapOrderToSchema(order));
  }
  
  async getOrderById(id: number): Promise<OrderWithItems | undefined> {
    try {
      const order = await OrderModel.findById(id);
      if (!order) return undefined;
      
      const orderItems = await OrderItemModel.find({ orderId: id });
      const restaurant = await RestaurantModel.findById(order.restaurantId);
      if (!restaurant) return undefined;
      
      const itemsWithDetails = await Promise.all(orderItems.map(async item => {
        const menuItem = await MenuItemModel.findById(item.menuItemId);
        return {
          ...this.mapOrderItemToSchema(item),
          menuItem: menuItem ? this.mapMenuItemToSchema(menuItem) : null
        };
      }));
      
      return {
        ...this.mapOrderToSchema(order),
        items: itemsWithDetails.filter(item => item.menuItem !== null),
        restaurant: this.mapRestaurantToSchema(restaurant)
      };
    } catch (error) {
      return undefined;
    }
  }
  
  async createOrder(order: InsertOrder, orderItems: InsertOrderItem[]): Promise<Order> {
    // Add initial status to history
    const orderWithHistory = {
      ...order,
      statusHistory: [{ status: order.status, timestamp: new Date() }]
    };
    
    // Create order
    const newOrder = await OrderModel.create(orderWithHistory);
    
    // Create order items
    await Promise.all(orderItems.map(item => 
      OrderItemModel.create({
        ...item,
        orderId: newOrder._id
      })
    ));
    
    return this.mapOrderToSchema(newOrder);
  }
  
  async updateOrderStatus(statusUpdate: StatusUpdate): Promise<Order | undefined> {
    try {
      const order = await OrderModel.findById(statusUpdate.orderId);
      if (!order) return undefined;
      
      // Update status
      order.status = statusUpdate.newStatus;
      
      // Add to status history
      order.statusHistory.push({
        status: statusUpdate.newStatus,
        timestamp: statusUpdate.timestamp
      });
      
      await order.save();
      
      return this.mapOrderToSchema(order);
    } catch (error) {
      return undefined;
    }
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    try {
      const user = await UserModel.findById(id);
      return user ? this.mapUserToSchema(user) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const user = await UserModel.findOne({ username });
      return user ? this.mapUserToSchema(user) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const newUser = await UserModel.create({
      ...user,
      addresses: []
    });
    
    return this.mapUserToSchema(newUser);
  }
  
  // Cart operations
  async getCart(userId?: number): Promise<Cart | undefined> {
    if (!userId) return undefined;
    
    try {
      const cart = await CartModel.findOne({ userId });
      return cart ? this.mapCartToSchema(cart) : undefined;
    } catch (error) {
      return undefined;
    }
  }
  
  async createOrUpdateCart(cart: InsertCart): Promise<Cart> {
    // Check if cart already exists for this user
    let existingCart;
    if (cart.userId) {
      existingCart = await CartModel.findOne({ userId: cart.userId });
    }
    
    let updatedCart;
    if (existingCart) {
      // Update existing cart
      existingCart.restaurantId = cart.restaurantId;
      existingCart.items = cart.items;
      updatedCart = await existingCart.save();
    } else {
      // Create new cart
      updatedCart = await CartModel.create(cart);
    }
    
    return this.mapCartToSchema(updatedCart);
  }
  
  // Analytics operations
  async getAnalytics(restaurantId: number, startDate?: Date, endDate?: Date): Promise<AnalyticsData> {
    // Build date filter
    const dateFilter: any = {};
    if (startDate) {
      dateFilter.$gte = startDate;
    }
    if (endDate) {
      dateFilter.$lte = endDate;
    }
    
    // Query parameters
    const query: any = { restaurantId };
    if (Object.keys(dateFilter).length > 0) {
      query.placedAt = dateFilter;
    }
    
    // Get all orders for this restaurant in the date range
    const orders = await OrderModel.find(query);
    
    // Get completed orders (not cancelled)
    const completedOrders = orders.filter(order => order.status !== 'cancelled');
    
    // Calculate total revenue
    const revenue = completedOrders.reduce((sum, order) => sum + order.totalAmount, 0);
    
    // Get pending orders
    const pendingOrders = orders.filter(order => 
      ['placed', 'confirmed', 'preparing', 'on_the_way'].includes(order.status)
    ).length;
    
    // Get all order items
    const orderIds = orders.map(order => order._id);
    const orderItems = await OrderItemModel.find({ orderId: { $in: orderIds } });
    
    // Get menu items for these orders
    const menuItemIds = [...new Set(orderItems.map(item => item.menuItemId.toString()))];
    const menuItems = await MenuItemModel.find({ _id: { $in: menuItemIds } });
    
    // Map of menu items by ID
    const menuItemsMap = new Map(
      menuItems.map(item => [item._id.toString(), this.mapMenuItemToSchema(item)])
    );
    
    // Aggregate order items by menu item
    const itemCounts = new Map<string, { name: string; count: number }>();
    
    for (const item of orderItems) {
      const menuItemId = item.menuItemId.toString();
      const menuItem = menuItemsMap.get(menuItemId);
      
      if (menuItem) {
        if (itemCounts.has(menuItemId)) {
          itemCounts.get(menuItemId)!.count += item.quantity;
        } else {
          itemCounts.set(menuItemId, { name: menuItem.name, count: item.quantity });
        }
      }
    }
    
    // Sort by count and take top 5
    const mostOrderedItems = [...itemCounts.values()]
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    
    // Calculate peak hours
    const hourCounts = new Map<string, number>();
    
    for (const order of orders) {
      const hour = new Date(order.placedAt).getHours();
      const hourString = `${hour}:00`;
      
      if (hourCounts.has(hourString)) {
        hourCounts.set(hourString, hourCounts.get(hourString)! + 1);
      } else {
        hourCounts.set(hourString, 1);
      }
    }
    
    const peakHours = [...hourCounts.entries()]
      .map(([hour, orders]) => ({ hour, orders }))
      .sort((a, b) => b.orders - a.orders);
    
    // Calculate orders by category
    const categoryRevenue = new Map<string, number>();
    
    for (const item of orderItems) {
      const menuItem = menuItemsMap.get(item.menuItemId.toString());
      if (menuItem) {
        const category = menuItem.category;
        const itemRevenue = item.totalPrice;
        
        if (categoryRevenue.has(category)) {
          categoryRevenue.set(category, categoryRevenue.get(category)! + itemRevenue);
        } else {
          categoryRevenue.set(category, itemRevenue);
        }
      }
    }
    
    const ordersByCategory = [...categoryRevenue.entries()]
      .map(([category, revenue]) => ({ category, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
    
    // Calculate average order value
    const averageOrderValue = completedOrders.length > 0
      ? Math.round(revenue / completedOrders.length)
      : 0;
    
    // Calculate returning customer percentage (simplified version)
    const customerIds = completedOrders.map(order => order.customerId?.toString()).filter(Boolean);
    const uniqueCustomers = new Set(customerIds).size;
    const returningCustomers = uniqueCustomers > 0
      ? customerIds.length - uniqueCustomers
      : 0;
    
    const returningCustomerPercentage = uniqueCustomers > 0
      ? Math.round((returningCustomers / uniqueCustomers) * 100)
      : 0;
    
    return {
      totalOrders: completedOrders.length,
      revenue,
      pendingOrders,
      mostOrderedItems,
      peakHours,
      ordersByCategory,
      averageOrderValue,
      returningCustomerPercentage
    };
  }
  
  // Helper methods to map MongoDB documents to schema types
  private mapRestaurantToSchema(restaurant: any): Restaurant {
    return {
      id: restaurant._id.toString(),
      name: restaurant.name,
      description: restaurant.description,
      cuisineTypes: restaurant.cuisineTypes,
      rating: restaurant.rating,
      deliveryTime: restaurant.deliveryTime,
      priceForTwo: restaurant.priceForTwo,
      imageUrl: restaurant.imageUrl,
      offers: restaurant.offers,
      isOpen: restaurant.isOpen
    };
  }
  
  private mapMenuItemToSchema(menuItem: any): MenuItem {
    return {
      id: menuItem._id.toString(),
      restaurantId: menuItem.restaurantId,
      name: menuItem.name,
      description: menuItem.description,
      price: menuItem.price,
      category: menuItem.category,
      imageUrl: menuItem.imageUrl,
      isVeg: menuItem.isVeg,
      inStock: menuItem.inStock,
      tags: menuItem.tags,
      ingredients: menuItem.ingredients
    };
  }
  
  private mapOrderToSchema(order: any): Order {
    return {
      id: order._id.toString(),
      restaurantId: order.restaurantId,
      customerId: order.customerId,
      status: order.status,
      totalAmount: order.totalAmount,
      deliveryFee: order.deliveryFee,
      tax: order.tax,
      paymentMethod: order.paymentMethod,
      deliveryAddress: order.deliveryAddress,
      placedAt: order.placedAt,
      estimatedDeliveryTime: order.estimatedDeliveryTime,
      specialInstructions: order.specialInstructions,
      statusHistory: order.statusHistory
    };
  }
  
  private mapOrderItemToSchema(orderItem: any): OrderItem {
    return {
      id: orderItem._id.toString(),
      orderId: orderItem.orderId,
      menuItemId: orderItem.menuItemId,
      quantity: orderItem.quantity,
      unitPrice: orderItem.unitPrice,
      totalPrice: orderItem.totalPrice,
      specialInstructions: orderItem.specialInstructions,
      customizations: orderItem.customizations
    };
  }
  
  private mapUserToSchema(user: any): User {
    return {
      id: user._id.toString(),
      username: user.username,
      password: user.password,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      addresses: user.addresses
    };
  }
  
  private mapCartToSchema(cart: any): Cart {
    return {
      id: cart._id.toString(),
      userId: cart.userId,
      restaurantId: cart.restaurantId,
      items: cart.items,
      createdAt: cart.createdAt,
      updatedAt: cart.updatedAt
    };
  }
}