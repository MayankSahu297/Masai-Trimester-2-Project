import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertRestaurantSchema } from '@shared/schema';
import { FilterOptions } from '@shared/types';
import { ZodError } from 'zod';
import { fromZodError } from 'zod-validation-error';

export const restaurantController = {
  getAll: async (req: Request, res: Response) => {
    try {
      // Parse filter parameters from query string
      const filters: FilterOptions = {
        sortBy: req.query.sortBy as any,
        filters: {
          cuisine: req.query.cuisine ? (req.query.cuisine as string).split(',') : undefined,
          veg: req.query.veg === 'true',
          maxDeliveryTime: req.query.maxDeliveryTime ? parseInt(req.query.maxDeliveryTime as string) : undefined,
          priceRange: req.query.priceRange 
            ? (req.query.priceRange as string).split('-').map(p => parseInt(p)) as [number, number] 
            : undefined
        }
      };
      
      const restaurants = await storage.getRestaurants(filters);
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch restaurants', error: error.message });
    }
  },
  
  getById: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const restaurant = await storage.getRestaurantById(id);
      if (!restaurant) {
        return res.status(404).json({ message: 'Restaurant not found' });
      }
      
      res.json(restaurant);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch restaurant', error: error.message });
    }
  },
  
  create: async (req: Request, res: Response) => {
    try {
      const validatedData = insertRestaurantSchema.parse(req.body);
      const restaurant = await storage.createRestaurant(validatedData);
      res.status(201).json(restaurant);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Failed to create restaurant', error: error.message });
    }
  },
  
  update: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      // Allow partial updates
      const validatedData = insertRestaurantSchema.partial().parse(req.body);
      
      const updatedRestaurant = await storage.updateRestaurant(id, validatedData);
      if (!updatedRestaurant) {
        return res.status(404).json({ message: 'Restaurant not found' });
      }
      
      res.json(updatedRestaurant);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Failed to update restaurant', error: error.message });
    }
  },
  
  delete: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const success = await storage.deleteRestaurant(id);
      if (!success) {
        return res.status(404).json({ message: 'Restaurant not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete restaurant', error: error.message });
    }
  }
};
