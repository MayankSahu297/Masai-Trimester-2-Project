import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertMenuItemSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { fromZodError } from 'zod-validation-error';

export const menuController = {
  getMenuByRestaurant: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const category = req.query.category as string | undefined;
      
      const menuItems = await storage.getMenuItems(restaurantId, category);
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch menu items', error: error.message });
    }
  },
  
  getMenuItemById: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid menu item ID' });
      }
      
      const menuItem = await storage.getMenuItemById(id);
      if (!menuItem) {
        return res.status(404).json({ message: 'Menu item not found' });
      }
      
      res.json(menuItem);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch menu item', error: error.message });
    }
  },
  
  createMenuItem: async (req: Request, res: Response) => {
    try {
      const validatedData = insertMenuItemSchema.parse(req.body);
      const menuItem = await storage.createMenuItem(validatedData);
      res.status(201).json(menuItem);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Failed to create menu item', error: error.message });
    }
  },
  
  updateMenuItem: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid menu item ID' });
      }
      
      // Allow partial updates
      const validatedData = insertMenuItemSchema.partial().parse(req.body);
      
      const updatedMenuItem = await storage.updateMenuItem(id, validatedData);
      if (!updatedMenuItem) {
        return res.status(404).json({ message: 'Menu item not found' });
      }
      
      res.json(updatedMenuItem);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Failed to update menu item', error: error.message });
    }
  },
  
  deleteMenuItem: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid menu item ID' });
      }
      
      const success = await storage.deleteMenuItem(id);
      if (!success) {
        return res.status(404).json({ message: 'Menu item not found' });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete menu item', error: error.message });
    }
  },
  
  searchMenuItems: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const search = req.query.q as string || '';
      
      // Enhanced filters with validation
      const filters = {
        category: req.query.category as string | undefined,
        isVeg: req.query.isVeg === 'true' ? true : (req.query.isVeg === 'false' ? false : undefined),
        priceRange: req.query.priceRange 
          ? (req.query.priceRange as string).split('-').map(p => parseInt(p)) as [number, number]
          : undefined,
        tags: req.query.tags ? (req.query.tags as string).split(',') : undefined,
        ingredients: req.query.ingredients ? (req.query.ingredients as string).split(',') : undefined,
        inStock: req.query.inStock === 'true' ? true : (req.query.inStock === 'false' ? false : undefined)
      };
      
      // Pagination parameters
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 20;
      const sortBy = req.query.sortBy as string || 'name';
      const sortOrder = req.query.sortOrder === 'desc' ? 'desc' : 'asc';
      
      const menuItems = await storage.searchMenuItems(restaurantId, search, filters);
      
      // Apply sorting
      const sortedItems = menuItems.sort((a, b) => {
        let aVal = a[sortBy as keyof typeof a];
        let bVal = b[sortBy as keyof typeof b];
        
        if (typeof aVal === 'string') aVal = aVal.toLowerCase();
        if (typeof bVal === 'string') bVal = bVal.toLowerCase();
        
        if (sortOrder === 'desc') {
          return aVal < bVal ? 1 : aVal > bVal ? -1 : 0;
        } else {
          return aVal > bVal ? 1 : aVal < bVal ? -1 : 0;
        }
      });
      
      // Apply pagination
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedItems = sortedItems.slice(startIndex, endIndex);
      
      res.json({
        items: paginatedItems,
        pagination: {
          page,
          limit,
          total: menuItems.length,
          totalPages: Math.ceil(menuItems.length / limit),
          hasNext: endIndex < menuItems.length,
          hasPrev: startIndex > 0
        },
        filters: filters,
        search: search
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to search menu items', error: error.message });
    }
  },

  // Bulk operations for menu management
  bulkUpdateMenuItems: async (req: Request, res: Response) => {
    try {
      const { updates } = req.body;
      
      if (!Array.isArray(updates)) {
        return res.status(400).json({ message: 'Updates must be an array' });
      }
      
      const results = [];
      
      for (const update of updates) {
        const { id, data } = update;
        if (!id || !data) {
          results.push({ id, success: false, error: 'Missing id or data' });
          continue;
        }
        
        try {
          const validatedData = insertMenuItemSchema.partial().parse(data);
          const updatedItem = await storage.updateMenuItem(id, validatedData);
          results.push({ id, success: !!updatedItem, item: updatedItem });
        } catch (error) {
          results.push({ id, success: false, error: error.message });
        }
      }
      
      res.json({ results });
    } catch (error) {
      res.status(500).json({ message: 'Failed to bulk update menu items', error: error.message });
    }
  },

  // Get menu categories for a restaurant
  getMenuCategories: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const menuItems = await storage.getMenuItems(restaurantId);
      const categories = [...new Set(menuItems.map(item => item.category))];
      
      res.json({ categories });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch menu categories', error: error.message });
    }
  },

  // Get popular menu items
  getPopularMenuItems: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const limit = parseInt(req.query.limit as string) || 10;
      
      // This would be enhanced with actual order data in MongoDB
      const menuItems = await storage.getMenuItems(restaurantId);
      
      // For now, return items sorted by a popularity score (could be based on orders)
      const popularItems = menuItems
        .filter(item => item.inStock)
        .sort((a, b) => b.price - a.price) // Placeholder sorting
        .slice(0, limit);
      
      res.json({ popular: popularItems });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch popular menu items', error: error.message });
    }
  }
};
