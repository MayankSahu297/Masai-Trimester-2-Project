import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertOrderSchema, insertOrderItemSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { fromZodError } from 'zod-validation-error';

export const orderController = {
  getOrders: async (req: Request, res: Response) => {
    try {
      const restaurantId = req.query.restaurantId ? parseInt(req.query.restaurantId as string) : undefined;
      const customerId = req.query.customerId ? parseInt(req.query.customerId as string) : undefined;
      const status = req.query.status as string | undefined;
      
      const orders = await storage.getOrders(restaurantId, customerId, status);
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch orders', error: error.message });
    }
  },
  
  getOrderById: async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrderById(id);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch order', error: error.message });
    }
  },
  
  createOrder: async (req: Request, res: Response) => {
    try {
      const { order, items } = req.body;
      
      // Validate order data
      const validatedOrder = insertOrderSchema.parse(order);
      
      // Validate each order item
      const validatedItems = [];
      for (const item of items) {
        validatedItems.push(insertOrderItemSchema.parse(item));
      }
      
      const newOrder = await storage.createOrder(validatedOrder, validatedItems);
      res.status(201).json(newOrder);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Failed to create order', error: error.message });
    }
  },
  
  updateOrderStatus: async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      // Validate the status update
      const { status } = req.body;
      if (!status || !['placed', 'confirmed', 'preparing', 'on_the_way', 'delivered', 'cancelled'].includes(status)) {
        return res.status(400).json({ message: 'Invalid status value' });
      }
      
      const statusUpdate = {
        orderId,
        newStatus: status,
        timestamp: new Date()
      };
      
      const updatedOrder = await storage.updateOrderStatus(statusUpdate);
      if (!updatedOrder) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      res.json(updatedOrder);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update order status', error: error.message });
    }
  },
  
  getCart: async (req: Request, res: Response) => {
    try {
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      const cart = await storage.getCart(userId);
      res.json(cart || { items: [] });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch cart', error: error.message });
    }
  },
  
  updateCart: async (req: Request, res: Response) => {
    try {
      const cart = req.body;
      
      // Validate cart data (simple validation for demo)
      if (!cart.restaurantId) {
        return res.status(400).json({ message: 'Restaurant ID is required' });
      }
      
      if (!Array.isArray(cart.items)) {
        return res.status(400).json({ message: 'Items should be an array' });
      }
      
      const updatedCart = await storage.createOrUpdateCart(cart);
      res.json(updatedCart);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update cart', error: error.message });
    }
  },

  // Enhanced order tracking and status management
  getOrderHistory: async (req: Request, res: Response) => {
    try {
      const customerId = parseInt(req.params.customerId);
      if (isNaN(customerId)) {
        return res.status(400).json({ message: 'Invalid customer ID' });
      }
      
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      const status = req.query.status as string | undefined;
      
      const orders = await storage.getOrders(undefined, customerId, status);
      
      // Sort by most recent first
      const sortedOrders = orders.sort((a, b) => 
        new Date(b.placedAt).getTime() - new Date(a.placedAt).getTime()
      );
      
      // Apply pagination
      const startIndex = (page - 1) * limit;
      const endIndex = startIndex + limit;
      const paginatedOrders = sortedOrders.slice(startIndex, endIndex);
      
      res.json({
        orders: paginatedOrders,
        pagination: {
          page,
          limit,
          total: orders.length,
          totalPages: Math.ceil(orders.length / limit),
          hasNext: endIndex < orders.length,
          hasPrev: startIndex > 0
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch order history', error: error.message });
    }
  },

  // Real-time order tracking
  trackOrder: async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrderById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Calculate estimated delivery time and progress
      const statusSteps = ['placed', 'confirmed', 'preparing', 'on_the_way', 'delivered'];
      const currentStepIndex = statusSteps.indexOf(order.status);
      const progress = order.status === 'cancelled' ? 0 : Math.round(((currentStepIndex + 1) / statusSteps.length) * 100);
      
      // Calculate time estimates
      const now = new Date();
      const orderTime = new Date(order.placedAt);
      const elapsedMinutes = Math.floor((now.getTime() - orderTime.getTime()) / (1000 * 60));
      
      let estimatedDeliveryTime = order.estimatedDeliveryTime || 30;
      let remainingTime = Math.max(0, estimatedDeliveryTime - elapsedMinutes);
      
      res.json({
        order,
        tracking: {
          currentStatus: order.status,
          progress,
          statusHistory: order.statusHistory,
          estimatedDeliveryTime,
          remainingTime,
          elapsedTime: elapsedMinutes,
          statusSteps: statusSteps.map((step, index) => ({
            step,
            completed: index <= currentStepIndex,
            current: index === currentStepIndex,
            timestamp: order.statusHistory?.find((h: any) => h.status === step)?.timestamp
          }))
        }
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to track order', error: error.message });
    }
  },

  // Bulk order status updates for restaurant staff
  bulkUpdateOrderStatus: async (req: Request, res: Response) => {
    try {
      const { updates } = req.body;
      
      if (!Array.isArray(updates)) {
        return res.status(400).json({ message: 'Updates must be an array' });
      }
      
      const results = [];
      
      for (const update of updates) {
        const { orderId, status } = update;
        
        if (!orderId || !status) {
          results.push({ orderId, success: false, error: 'Missing orderId or status' });
          continue;
        }
        
        if (!['placed', 'confirmed', 'preparing', 'on_the_way', 'delivered', 'cancelled'].includes(status)) {
          results.push({ orderId, success: false, error: 'Invalid status value' });
          continue;
        }
        
        try {
          const statusUpdate = {
            orderId: parseInt(orderId),
            newStatus: status,
            timestamp: new Date()
          };
          
          const updatedOrder = await storage.updateOrderStatus(statusUpdate);
          results.push({ orderId, success: !!updatedOrder, order: updatedOrder });
        } catch (error) {
          results.push({ orderId, success: false, error: error.message });
        }
      }
      
      res.json({ results });
    } catch (error) {
      res.status(500).json({ message: 'Failed to bulk update order status', error: error.message });
    }
  },

  // Order modification for in-progress orders
  modifyOrder: async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const order = await storage.getOrderById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Only allow modifications for orders that haven't started preparing
      if (!['placed', 'confirmed'].includes(order.status)) {
        return res.status(400).json({ message: 'Order cannot be modified at this stage' });
      }
      
      const { action, items } = req.body;
      
      if (action === 'add_items' && items) {
        // Add new items to the order (would require implementation in storage)
        res.json({ message: 'Items added successfully', order });
      } else if (action === 'remove_items' && items) {
        // Remove items from the order
        res.json({ message: 'Items removed successfully', order });
      } else if (action === 'update_instructions') {
        // Update special instructions
        res.json({ message: 'Instructions updated successfully', order });
      } else {
        res.status(400).json({ message: 'Invalid action or missing data' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Failed to modify order', error: error.message });
    }
  },

  // Cancel order with confirmation
  cancelOrder: async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: 'Invalid order ID' });
      }
      
      const { reason } = req.body;
      
      const order = await storage.getOrderById(orderId);
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      // Check if order can be cancelled
      if (['delivered', 'cancelled'].includes(order.status)) {
        return res.status(400).json({ message: 'Order cannot be cancelled' });
      }
      
      const statusUpdate = {
        orderId,
        newStatus: 'cancelled' as const,
        timestamp: new Date()
      };
      
      const updatedOrder = await storage.updateOrderStatus(statusUpdate);
      
      res.json({
        message: 'Order cancelled successfully',
        order: updatedOrder,
        cancellationReason: reason
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to cancel order', error: error.message });
    }
  }
};
