import { pgTable, text, serial, integer, boolean, timestamp, json, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { FilterOptions, StatusUpdate, AnalyticsData } from '@shared/types';

// Restaurant Schema
export const restaurants = pgTable("restaurants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  cuisineTypes: text("cuisine_types").array().notNull(),
  rating: doublePrecision("rating"),
  deliveryTime: integer("delivery_time").notNull(),
  priceForTwo: integer("price_for_two").notNull(),
  imageUrl: text("image_url").notNull(),
  offers: text("offers").array(),
  isOpen: boolean("is_open").notNull().default(true),
});

export const insertRestaurantSchema = createInsertSchema(restaurants).omit({ id: true });
export type InsertRestaurant = z.infer<typeof insertRestaurantSchema>;
export type Restaurant = typeof restaurants.$inferSelect;

// Menu Item Schema
export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url"),
  isVeg: boolean("is_veg").notNull(),
  inStock: boolean("in_stock").notNull().default(true),
  tags: text("tags").array(),
  ingredients: text("ingredients").array(),
});

export const insertMenuItemSchema = createInsertSchema(menuItems).omit({ id: true });
export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
export type MenuItem = typeof menuItems.$inferSelect;

// Order Schema
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  customerId: integer("customer_id"),
  status: text("status").notNull(), // "placed", "confirmed", "preparing", "on_the_way", "delivered", "cancelled"
  totalAmount: integer("total_amount").notNull(),
  deliveryFee: integer("delivery_fee").notNull(),
  tax: integer("tax").notNull(),
  paymentMethod: text("payment_method").notNull(),
  deliveryAddress: text("delivery_address"),
  placedAt: timestamp("placed_at").notNull().defaultNow(),
  estimatedDeliveryTime: integer("estimated_delivery_time"),
  specialInstructions: text("special_instructions"),
  statusHistory: json("status_history").notNull().default([]),
});

export const insertOrderSchema = createInsertSchema(orders).omit({ id: true, placedAt: true, statusHistory: true });
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

// Order Item Schema
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  menuItemId: integer("menu_item_id").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: integer("unit_price").notNull(),
  totalPrice: integer("total_price").notNull(),
  specialInstructions: text("special_instructions"),
  customizations: json("customizations").default({}),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({ id: true });
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;
export type OrderItem = typeof orderItems.$inferSelect;

// User Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  role: text("role").notNull().default("customer"), // "customer" or "admin"
  addresses: json("addresses").default([]),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, addresses: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Cart Schema (for saving carts in progress)
export const carts = pgTable("carts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  restaurantId: integer("restaurant_id").notNull(),
  items: json("items").notNull().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertCartSchema = createInsertSchema(carts).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertCart = z.infer<typeof insertCartSchema>;
export type Cart = typeof carts.$inferSelect;

// OrderWithItems type for getting order with its items
export type OrderWithItems = Order & {
  items: (OrderItem & { menuItem: MenuItem })[];
  restaurant: Restaurant;
};

// Storage interface definition
export interface IRestaurantStorage {
  // Restaurant operations
  getRestaurants(filters?: FilterOptions): Promise<Restaurant[]>;
  getRestaurantById(id: number): Promise<Restaurant | undefined>;
  createRestaurant(restaurant: InsertRestaurant): Promise<Restaurant>;
  updateRestaurant(id: number, restaurant: Partial<InsertRestaurant>): Promise<Restaurant | undefined>;
  deleteRestaurant(id: number): Promise<boolean>;
  
  // Menu operations
  getMenuItems(restaurantId: number, category?: string): Promise<MenuItem[]>;
  getMenuItemById(id: number): Promise<MenuItem | undefined>;
  createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: number, menuItem: Partial<InsertMenuItem>): Promise<MenuItem | undefined>;
  deleteMenuItem(id: number): Promise<boolean>;
  searchMenuItems(
    restaurantId: number, 
    search: string, 
    filters?: { category?: string, isVeg?: boolean, priceRange?: [number, number], tags?: string[] }
  ): Promise<MenuItem[]>;
  
  // Order operations
  getOrders(restaurantId?: number, customerId?: number, status?: string): Promise<Order[]>;
  getOrderById(id: number): Promise<OrderWithItems | undefined>;
  createOrder(order: InsertOrder, orderItems: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(statusUpdate: StatusUpdate): Promise<Order | undefined>;
  
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Cart operations
  getCart(userId?: number): Promise<Cart | undefined>;
  createOrUpdateCart(cart: InsertCart): Promise<Cart>;
  
  // Analytics operations
  getAnalytics(restaurantId: number, startDate?: Date, endDate?: Date): Promise<AnalyticsData>;
}
