import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { initializeStorage } from "./storage/index";
import { restaurantController } from "./controllers/restaurant.controller";
import { menuController } from "./controllers/menu.controller";
import { orderController } from "./controllers/order.controller";
import { authController } from "./controllers/auth.controller";
import { analyticsController } from "./controllers/analytics.controller";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize storage (MongoDB or in-memory)
  try {
    await initializeStorage();
    console.log("Storage initialized successfully");
  } catch (error) {
    console.error("Error initializing storage:", error);
  }
  
  // prefix all routes with /api
  const apiRouter = '/api';
  
  // Auth routes
  app.post(`${apiRouter}/auth/login`, authController.login);
  app.post(`${apiRouter}/auth/register`, authController.register);
  app.get(`${apiRouter}/auth/me`, authController.getCurrentUser);
  app.post(`${apiRouter}/auth/logout`, authController.logout);
  
  // Restaurant routes
  app.get(`${apiRouter}/restaurants`, restaurantController.getAll);
  app.get(`${apiRouter}/restaurants/:id`, restaurantController.getById);
  app.post(`${apiRouter}/restaurants`, restaurantController.create);
  app.put(`${apiRouter}/restaurants/:id`, restaurantController.update);
  app.delete(`${apiRouter}/restaurants/:id`, restaurantController.delete);
  
  // Menu routes
  app.get(`${apiRouter}/restaurants/:restaurantId/menu`, menuController.getMenuByRestaurant);
  app.get(`${apiRouter}/menu/:id`, menuController.getMenuItemById);
  app.post(`${apiRouter}/menu`, menuController.createMenuItem);
  app.put(`${apiRouter}/menu/:id`, menuController.updateMenuItem);
  app.delete(`${apiRouter}/menu/:id`, menuController.deleteMenuItem);
  app.get(`${apiRouter}/restaurants/:restaurantId/menu/search`, menuController.searchMenuItems);
  
  // Enhanced menu routes
  app.patch(`${apiRouter}/menu/bulk-update`, menuController.bulkUpdateMenuItems);
  app.get(`${apiRouter}/restaurants/:restaurantId/menu/categories`, menuController.getMenuCategories);
  app.get(`${apiRouter}/restaurants/:restaurantId/menu/popular`, menuController.getPopularMenuItems);
  
  // Order routes
  app.get(`${apiRouter}/orders`, orderController.getOrders);
  app.get(`${apiRouter}/orders/:id`, orderController.getOrderById);
  app.post(`${apiRouter}/orders`, orderController.createOrder);
  app.put(`${apiRouter}/orders/:id/status`, orderController.updateOrderStatus);
  
  // Enhanced order management routes
  app.get(`${apiRouter}/customers/:customerId/orders`, orderController.getOrderHistory);
  app.get(`${apiRouter}/orders/:id/track`, orderController.trackOrder);
  app.patch(`${apiRouter}/orders/bulk-status`, orderController.bulkUpdateOrderStatus);
  app.patch(`${apiRouter}/orders/:id/modify`, orderController.modifyOrder);
  app.delete(`${apiRouter}/orders/:id/cancel`, orderController.cancelOrder);
  
  // Cart routes
  app.get(`${apiRouter}/cart`, orderController.getCart);
  app.post(`${apiRouter}/cart`, orderController.updateCart);
  
  // Analytics routes
  app.get(`${apiRouter}/analytics/:restaurantId`, analyticsController.getRestaurantAnalytics);
  app.get(`${apiRouter}/analytics/:restaurantId/daily`, analyticsController.getDailySalesReport);
  app.get(`${apiRouter}/analytics/:restaurantId/weekly`, analyticsController.getWeeklySalesReport);
  app.get(`${apiRouter}/analytics/:restaurantId/items`, analyticsController.getItemWiseSales);
  app.get(`${apiRouter}/analytics/:restaurantId/categories`, analyticsController.getCategoryRevenue);
  app.get(`${apiRouter}/analytics/:restaurantId/peak-hours`, analyticsController.getPeakHoursAnalysis);
  
  const httpServer = createServer(app);
  return httpServer;
}
