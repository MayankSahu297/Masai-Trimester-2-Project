import { Request, Response } from 'express';
import { storage } from '../storage';
import { insertUserSchema } from '@shared/schema';
import { ZodError } from 'zod';
import { fromZodError } from 'zod-validation-error';

export const authController = {
  login: async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // In a real app, you would use bcrypt to compare hashed passwords
      if (user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // For simplicity, we'll just return the user without passwords
      // In a real app, you would set up a session or generate a JWT
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({
        message: 'Login successful',
        user: userWithoutPassword
      });
    } catch (error) {
      res.status(500).json({ message: 'Login failed', error: error.message });
    }
  },
  
  register: async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: 'Username already taken' });
      }
      
      // In a real app, you would hash the password before storing
      const user = await storage.createUser(userData);
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      
      res.status(201).json({
        message: 'Registration successful',
        user: userWithoutPassword
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: 'Validation error', errors: validationError.details });
      }
      res.status(500).json({ message: 'Registration failed', error: error.message });
    }
  },
  
  getCurrentUser: async (req: Request, res: Response) => {
    // This is a simplified version for demo purposes
    // In a real app, you would get the current user from the session or JWT
    const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
    
    if (!userId) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    
    try {
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user', error: error.message });
    }
  },
  
  logout: async (req: Request, res: Response) => {
    // In a real app, you would destroy the session or invalidate the JWT
    res.json({ message: 'Logout successful' });
  }
};
