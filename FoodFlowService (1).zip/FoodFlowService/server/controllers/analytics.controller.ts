import { Request, Response } from 'express';
import { storage } from '../storage';

export const analyticsController = {
  getRestaurantAnalytics: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      // Parse date range if provided
      let startDate: Date | undefined;
      let endDate: Date | undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
        if (isNaN(startDate.getTime())) {
          return res.status(400).json({ message: 'Invalid start date format' });
        }
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
        if (isNaN(endDate.getTime())) {
          return res.status(400).json({ message: 'Invalid end date format' });
        }
      }
      
      const analytics = await storage.getAnalytics(restaurantId, startDate, endDate);
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch analytics', error: error.message });
    }
  },

  // Daily sales report
  getDailySalesReport: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const date = req.query.date ? new Date(req.query.date as string) : new Date();
      const startOfDay = new Date(date.setHours(0, 0, 0, 0));
      const endOfDay = new Date(date.setHours(23, 59, 59, 999));
      
      const analytics = await storage.getAnalytics(restaurantId, startOfDay, endOfDay);
      
      res.json({
        date: startOfDay.toISOString().split('T')[0],
        totalOrders: analytics.totalOrders,
        revenue: analytics.revenue,
        averageOrderValue: analytics.averageOrderValue,
        mostOrderedItems: analytics.mostOrderedItems,
        peakHours: analytics.peakHours
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch daily sales report', error: error.message });
    }
  },

  // Weekly sales report
  getWeeklySalesReport: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      const date = req.query.date ? new Date(req.query.date as string) : new Date();
      const startOfWeek = new Date(date.setDate(date.getDate() - date.getDay()));
      startOfWeek.setHours(0, 0, 0, 0);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(endOfWeek.getDate() + 6);
      endOfWeek.setHours(23, 59, 59, 999);
      
      const analytics = await storage.getAnalytics(restaurantId, startOfWeek, endOfWeek);
      
      res.json({
        weekStart: startOfWeek.toISOString().split('T')[0],
        weekEnd: endOfWeek.toISOString().split('T')[0],
        totalOrders: analytics.totalOrders,
        revenue: analytics.revenue,
        averageOrderValue: analytics.averageOrderValue,
        ordersByCategory: analytics.ordersByCategory,
        returningCustomerPercentage: analytics.returningCustomerPercentage
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch weekly sales report', error: error.message });
    }
  },

  // Item-wise sales analysis
  getItemWiseSales: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      let startDate: Date | undefined;
      let endDate: Date | undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const analytics = await storage.getAnalytics(restaurantId, startDate, endDate);
      
      // Get menu items for additional details
      const menuItems = await storage.getMenuItems(restaurantId);
      const menuMap = new Map(menuItems.map(item => [item.name, item]));
      
      const itemAnalysis = analytics.mostOrderedItems.map(item => {
        const menuItem = menuMap.get(item.name);
        return {
          ...item,
          category: menuItem?.category,
          price: menuItem?.price,
          revenue: (menuItem?.price || 0) * item.count,
          isVeg: menuItem?.isVeg
        };
      });
      
      res.json({
        items: itemAnalysis,
        totalItems: itemAnalysis.length,
        topPerformers: itemAnalysis.slice(0, 5)
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch item-wise sales', error: error.message });
    }
  },

  // Category-wise revenue breakdown
  getCategoryRevenue: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      let startDate: Date | undefined;
      let endDate: Date | undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const analytics = await storage.getAnalytics(restaurantId, startDate, endDate);
      
      const totalRevenue = analytics.ordersByCategory.reduce((sum, cat) => sum + cat.revenue, 0);
      
      const categoryBreakdown = analytics.ordersByCategory.map(category => ({
        ...category,
        percentage: totalRevenue > 0 ? Math.round((category.revenue / totalRevenue) * 100) : 0
      }));
      
      res.json({
        categories: categoryBreakdown,
        totalRevenue,
        topCategory: categoryBreakdown[0] || null
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch category revenue', error: error.message });
    }
  },

  // Peak hours analysis
  getPeakHoursAnalysis: async (req: Request, res: Response) => {
    try {
      const restaurantId = parseInt(req.params.restaurantId);
      if (isNaN(restaurantId)) {
        return res.status(400).json({ message: 'Invalid restaurant ID' });
      }
      
      let startDate: Date | undefined;
      let endDate: Date | undefined;
      
      if (req.query.startDate) {
        startDate = new Date(req.query.startDate as string);
      }
      
      if (req.query.endDate) {
        endDate = new Date(req.query.endDate as string);
      }
      
      const analytics = await storage.getAnalytics(restaurantId, startDate, endDate);
      
      // Enhance peak hours with additional insights
      const totalOrders = analytics.peakHours.reduce((sum, hour) => sum + hour.orders, 0);
      
      const enhancedPeakHours = analytics.peakHours.map(hour => ({
        ...hour,
        percentage: totalOrders > 0 ? Math.round((hour.orders / totalOrders) * 100) : 0
      }));
      
      const peakHour = enhancedPeakHours.reduce((max, hour) => 
        hour.orders > max.orders ? hour : max, enhancedPeakHours[0] || { hour: 'N/A', orders: 0 }
      );
      
      res.json({
        hourlyBreakdown: enhancedPeakHours,
        peakHour: peakHour,
        totalOrders: totalOrders,
        averageOrdersPerHour: totalOrders > 0 ? Math.round(totalOrders / 24) : 0
      });
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch peak hours analysis', error: error.message });
    }
  }
};
