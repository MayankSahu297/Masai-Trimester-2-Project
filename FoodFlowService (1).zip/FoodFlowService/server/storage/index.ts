import { MemStorage } from '../storage';
import { MongoStorage } from './mongo.storage';
import { connectToDatabase } from '../models';
import { IRestaurantStorage } from '@shared/schema';

// Global storage instance
let storage: IRestaurantStorage;

// Function to initialize the storage
export async function initializeStorage(): Promise<IRestaurantStorage> {
  // If storage is already initialized, return it
  if (storage) {
    return storage;
  }
  
  // Check if we should use MongoDB or memory storage
  const useMongoDb = process.env.USE_MONGODB === 'true';
  
  if (useMongoDb) {
    console.log('Initializing MongoDB storage...');
    try {
      // Connect to MongoDB
      const connected = await connectToDatabase();
      
      if (connected) {
        storage = new MongoStorage();
        console.log('MongoDB storage initialized');
      } else {
        console.log('MongoDB connection failed, falling back to in-memory storage');
        storage = new MemStorage();
      }
    } catch (error) {
      console.error('Error initializing MongoDB storage:', error);
      console.log('Falling back to in-memory storage');
      storage = new MemStorage();
    }
  } else {
    console.log('Initializing in-memory storage...');
    storage = new MemStorage();
  }
  
  return storage;
}

// Export the storage instance and initialization function
export { storage };