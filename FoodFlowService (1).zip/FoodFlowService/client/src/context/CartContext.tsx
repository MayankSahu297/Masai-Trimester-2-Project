import { createContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { MenuItem, Restaurant } from '@shared/schema';
import { CartItemType, CartType } from '@shared/types';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

type CartContextType = {
  cart: CartType;
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (restaurant: Restaurant, menuItem: MenuItem, quantity: number) => void;
  removeFromCart: (menuItemId: number) => void;
  updateItemQuantity: (menuItemId: number, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => { subtotal: number, tax: number, deliveryFee: number, total: number };
  itemCount: number;
};

export const CartContext = createContext<CartContextType>({
  cart: { restaurant: null, items: [], deliveryFee: 0, tax: 0 },
  isCartOpen: false,
  openCart: () => {},
  closeCart: () => {},
  addToCart: () => {},
  removeFromCart: () => {},
  updateItemQuantity: () => {},
  clearCart: () => {},
  getCartTotal: () => ({ subtotal: 0, tax: 0, deliveryFee: 0, total: 0 }),
  itemCount: 0,
});

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const { toast } = useToast();
  const [cart, setCart] = useState<CartType>({
    restaurant: null,
    items: [],
    deliveryFee: 30, // Default delivery fee
    tax: 0, // Will be calculated based on subtotal
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [itemCount, setItemCount] = useState(0);

  // Calculate total items in cart
  useEffect(() => {
    const count = cart.items.reduce((total, item) => total + item.quantity, 0);
    setItemCount(count);
  }, [cart.items]);

  const openCart = useCallback(() => {
    setIsCartOpen(true);
  }, []);

  const closeCart = useCallback(() => {
    setIsCartOpen(false);
  }, []);

  const addToCart = useCallback((restaurant: Restaurant, menuItem: MenuItem, quantity: number) => {
    setCart(prevCart => {
      // If adding from a different restaurant, clear cart first
      if (prevCart.restaurant && prevCart.restaurant.id !== restaurant.id) {
        toast({
          title: "Cart cleared",
          description: `Your previous items were removed because you're ordering from a different restaurant.`,
          variant: "destructive",
        });
        return {
          restaurant,
          items: [{ menuItem, quantity }],
          deliveryFee: 30,
          tax: Math.round(menuItem.price * quantity * 0.05), // 5% tax
        };
      }

      // Check if item already exists in cart
      const existingItemIndex = prevCart.items.findIndex(
        item => item.menuItem.id === menuItem.id
      );

      let newItems;
      if (existingItemIndex >= 0) {
        // Update quantity if item exists
        newItems = [...prevCart.items];
        newItems[existingItemIndex].quantity += quantity;
      } else {
        // Add new item
        newItems = [...prevCart.items, { menuItem, quantity }];
      }

      // Calculate new tax based on updated items
      const subtotal = newItems.reduce(
        (sum, item) => sum + item.menuItem.price * item.quantity, 
        0
      );
      const tax = Math.round(subtotal * 0.05); // 5% tax

      toast({
        title: "Added to cart",
        description: `${quantity} x ${menuItem.name} added to your cart.`,
      });

      return {
        restaurant,
        items: newItems,
        deliveryFee: prevCart.deliveryFee,
        tax,
      };
    });

    // Open cart when adding items
    openCart();
  }, [openCart, toast]);

  const removeFromCart = useCallback((menuItemId: number) => {
    setCart(prevCart => {
      const newItems = prevCart.items.filter(
        item => item.menuItem.id !== menuItemId
      );

      // If cart becomes empty, set restaurant to null
      if (newItems.length === 0) {
        return {
          restaurant: null,
          items: [],
          deliveryFee: 30,
          tax: 0,
        };
      }

      // Recalculate tax
      const subtotal = newItems.reduce(
        (sum, item) => sum + item.menuItem.price * item.quantity, 
        0
      );
      const tax = Math.round(subtotal * 0.05); // 5% tax

      return {
        ...prevCart,
        items: newItems,
        tax,
      };
    });
  }, []);

  const updateItemQuantity = useCallback((menuItemId: number, quantity: number) => {
    setCart(prevCart => {
      if (quantity <= 0) {
        return {
          ...prevCart,
          items: prevCart.items.filter(item => item.menuItem.id !== menuItemId),
        };
      }

      const newItems = prevCart.items.map(item => 
        item.menuItem.id === menuItemId 
          ? { ...item, quantity } 
          : item
      );

      // Recalculate tax
      const subtotal = newItems.reduce(
        (sum, item) => sum + item.menuItem.price * item.quantity, 
        0
      );
      const tax = Math.round(subtotal * 0.05); // 5% tax

      return {
        ...prevCart,
        items: newItems,
        tax,
      };
    });
  }, []);

  const clearCart = useCallback(() => {
    setCart({
      restaurant: null,
      items: [],
      deliveryFee: 30,
      tax: 0,
    });
  }, []);

  const getCartTotal = useCallback(() => {
    const subtotal = cart.items.reduce(
      (sum, item) => sum + item.menuItem.price * item.quantity, 
      0
    );
    
    const { deliveryFee, tax } = cart;
    const total = subtotal + deliveryFee + tax;
    
    return { subtotal, tax, deliveryFee, total };
  }, [cart]);

  return (
    <CartContext.Provider
      value={{
        cart,
        isCartOpen,
        openCart,
        closeCart,
        addToCart,
        removeFromCart,
        updateItemQuantity,
        clearCart,
        getCartTotal,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
