import { createContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { User } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

type AuthContextType = {
  user: User | null;
  isLoading: boolean;
  isAdmin: boolean;
  login: (username: string, password: string) => Promise<void>;
  register: (userData: { username: string; password: string; name: string; email: string; phone?: string }) => Promise<void>;
  logout: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  isAdmin: false,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
});

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const checkAuthStatus = useCallback(async () => {
    try {
      // In a real application, this would use sessions or JWT tokens
      // For simplicity, we'll check if there's a userId in localStorage
      const userId = localStorage.getItem('userId');
      
      if (userId) {
        const res = await fetch(`/api/auth/me?userId=${userId}`, {
          credentials: 'include',
        });
        
        if (res.ok) {
          const userData = await res.json();
          setUser(userData);
        } else {
          // Clear invalid stored user
          localStorage.removeItem('userId');
          setUser(null);
        }
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuthStatus();
  }, [checkAuthStatus]);

  const login = async (username: string, password: string) => {
    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/auth/login', { username, password });
      const data = await res.json();
      
      setUser(data.user);
      
      // In a real app, the session would be handled by the server
      // This is just for the demo
      localStorage.setItem('userId', data.user.id.toString());
      
      toast({
        title: 'Login successful',
        description: `Welcome back, ${data.user.name}!`,
      });
    } catch (error) {
      toast({
        title: 'Login failed',
        description: error.message || 'Invalid credentials',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (userData: { username: string; password: string; name: string; email: string; phone?: string }) => {
    setIsLoading(true);
    try {
      const res = await apiRequest('POST', '/api/auth/register', userData);
      const data = await res.json();
      
      setUser(data.user);
      
      // In a real app, the session would be handled by the server
      localStorage.setItem('userId', data.user.id.toString());
      
      toast({
        title: 'Registration successful',
        description: `Welcome, ${data.user.name}!`,
      });
    } catch (error) {
      toast({
        title: 'Registration failed',
        description: error.message || 'Could not create account',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await apiRequest('POST', '/api/auth/logout', {});
      setUser(null);
      localStorage.removeItem('userId');
      
      toast({
        title: 'Logged out',
        description: 'You have been successfully logged out.',
      });
    } catch (error) {
      toast({
        title: 'Logout failed',
        description: error.message || 'Could not log out',
        variant: 'destructive',
      });
    }
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        isLoading, 
        isAdmin: user?.role === 'admin', 
        login, 
        register, 
        logout 
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
