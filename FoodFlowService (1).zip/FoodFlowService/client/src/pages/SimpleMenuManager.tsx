import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

const SimpleMenuManager = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const restaurantId = 1; // Default to first restaurant
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    isVeg: false,
    inStock: true,
    tags: '',
    ingredients: ''
  });

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [vegFilter, setVegFilter] = useState('all');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  
  // Edit dialog state
  const [editItem, setEditItem] = useState<any>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  
  // Analytics state
  const [showAnalytics, setShowAnalytics] = useState(false);

  // Enhanced menu query with search and filters
  const buildSearchQuery = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.append('q', searchQuery);
    if (categoryFilter) params.append('category', categoryFilter);
    if (vegFilter !== 'all') params.append('isVeg', vegFilter);
    if (priceRange.min) params.append('priceRange', `${priceRange.min}-${priceRange.max || '9999'}`);
    if (sortBy) params.append('sortBy', sortBy);
    if (sortOrder) params.append('sortOrder', sortOrder);
    return params.toString();
  };

  const { data: searchResponse, isLoading } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu/search`, searchQuery, categoryFilter, vegFilter, priceRange, sortBy, sortOrder],
    queryFn: async () => {
      const queryString = buildSearchQuery();
      const url = queryString 
        ? `/api/restaurants/${restaurantId}/menu/search?${queryString}`
        : `/api/restaurants/${restaurantId}/menu`;
      const response = await fetch(url);
      return response.json();
    }
  });

  const menuItems = searchResponse?.items || searchResponse || [];

  // Analytics query
  const { data: analytics } = useQuery({
    queryKey: [`/api/analytics/${restaurantId}`],
    enabled: showAnalytics
  });

  // Categories query for filter dropdown
  const { data: categoriesData } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu/categories`]
  });

  const categories = categoriesData?.categories || [];

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/menu', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      toast({
        title: "Success",
        description: "Menu item added successfully",
      });
      // Reset form
      setFormData({
        name: '',
        description: '',
        price: '',
        category: '',
        isVeg: false,
        inStock: true,
        tags: '',
        ingredients: ''
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add menu item",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.description || !formData.price || !formData.category) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    const price = parseInt(formData.price);
    if (isNaN(price) || price <= 0) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid price",
        variant: "destructive",
      });
      return;
    }

    const submitData = {
      restaurantId,
      name: formData.name,
      description: formData.description,
      price: price,
      category: formData.category,
      isVeg: formData.isVeg,
      inStock: formData.inStock,
      tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()).filter(Boolean) : [],
      ingredients: formData.ingredients ? formData.ingredients.split(',').map(ing => ing.trim()).filter(Boolean) : []
    };

    createMutation.mutate(submitData);
  };

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Update and delete operations
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest('PUT', `/api/menu/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu/search`] });
      toast({
        title: "Success",
        description: "Menu item updated successfully",
      });
      setIsEditDialogOpen(false);
      setEditItem(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update menu item",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/menu/${id}`, undefined);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu/search`] });
      toast({
        title: "Success",
        description: "Menu item deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete menu item",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (item: any) => {
    setEditItem({
      ...item,
      tags: Array.isArray(item.tags) ? item.tags.join(', ') : '',
      ingredients: Array.isArray(item.ingredients) ? item.ingredients.join(', ') : ''
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = () => {
    if (!editItem) return;
    const price = parseInt(editItem.price);
    if (isNaN(price) || price <= 0) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid price",
        variant: "destructive",
      });
      return;
    }

    const formattedData = {
      name: editItem.name,
      description: editItem.description,
      price: price,
      category: editItem.category,
      isVeg: editItem.isVeg,
      inStock: editItem.inStock,
      tags: editItem.tags ? editItem.tags.split(',').map((tag: string) => tag.trim()).filter(Boolean) : [],
      ingredients: editItem.ingredients ? editItem.ingredients.split(',').map((ing: string) => ing.trim()).filter(Boolean) : [],
      restaurantId
    };

    updateMutation.mutate({ id: editItem.id, data: formattedData });
  };

  const handleDelete = (id: number, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
      deleteMutation.mutate(id);
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setCategoryFilter('');
    setVegFilter('all');
    setPriceRange({ min: '', max: '' });
    setSortBy('name');
    setSortOrder('asc');
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      <Tabs defaultValue="menu" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="menu">Menu Management</TabsTrigger>
          <TabsTrigger value="search">Advanced Search</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="orders">Order Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="menu" className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Add Menu Item</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name">Item Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g., Butter Chicken"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="category">Category *</Label>
              <Input
                id="category"
                value={formData.category}
                onChange={(e) => handleChange('category', e.target.value)}
                placeholder="e.g., Main Course, Appetizer, Dessert"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="price">Price (in rupees) *</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={(e) => handleChange('price', e.target.value)}
                placeholder="e.g., 299"
                required
              />
            </div>
            
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.isVeg}
                  onCheckedChange={(checked) => handleChange('isVeg', checked)}
                />
                <Label>Vegetarian</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  checked={formData.inStock}
                  onCheckedChange={(checked) => handleChange('inStock', checked)}
                />
                <Label>In Stock</Label>
              </div>
            </div>
          </div>
          
          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="Describe the dish..."
              required
            />
          </div>
          
          <div>
            <Label htmlFor="ingredients">Ingredients (comma separated)</Label>
            <Input
              id="ingredients"
              value={formData.ingredients}
              onChange={(e) => handleChange('ingredients', e.target.value)}
              placeholder="e.g., chicken, tomato, cream, spices"
            />
          </div>
          
          <div>
            <Label htmlFor="tags">Tags (comma separated)</Label>
            <Input
              id="tags"
              value={formData.tags}
              onChange={(e) => handleChange('tags', e.target.value)}
              placeholder="e.g., spicy, popular, creamy"
            />
          </div>
          
          <Button 
            type="submit" 
            className="w-full md:w-auto px-8"
            disabled={createMutation.isPending}
          >
            {createMutation.isPending ? 'Adding...' : 'Add Menu Item'}
          </Button>
        </form>
      </div>

      {/* Current Menu Items */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Current Menu Items</h2>
        
        {isLoading ? (
          <div className="text-center py-8">Loading menu items...</div>
        ) : menuItems && menuItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {menuItems.map((item: any) => (
              <div key={item.id} className="border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold text-lg">{item.name}</h3>
                <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-bold text-green-600">₹{item.price}</span>
                  <span className="text-xs bg-gray-100 px-2 py-1 rounded">{item.category}</span>
                </div>
                {item.isVeg && (
                  <span className="inline-block mt-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                    Vegetarian
                  </span>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            No menu items yet. Add your first item above!
          </div>
        )}
      </div>
    </div>
  );
};

export default SimpleMenuManager;