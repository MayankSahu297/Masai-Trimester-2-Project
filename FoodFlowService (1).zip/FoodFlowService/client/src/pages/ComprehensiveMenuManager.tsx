import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

const ComprehensiveMenuManager = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const restaurantId = 1;
  
  const [formData, setFormData] = useState({
    name: '', description: '', price: '', category: '',
    isVeg: false, inStock: true, tags: '', ingredients: ''
  });

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [vegFilter, setVegFilter] = useState('all');
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [sortBy, setSortBy] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');
  
  // Edit dialog state
  const [editItem, setEditItem] = useState<any>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);

  // Enhanced menu query with search
  const buildSearchQuery = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.append('q', searchQuery);
    if (categoryFilter && categoryFilter !== 'all') params.append('category', categoryFilter);
    if (vegFilter !== 'all') params.append('isVeg', vegFilter);
    if (priceRange.min) params.append('priceRange', `${priceRange.min}-${priceRange.max || '9999'}`);
    if (sortBy) params.append('sortBy', sortBy);
    if (sortOrder) params.append('sortOrder', sortOrder);
    return params.toString();
  };

  const { data: searchResponse, isLoading } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu/search`, searchQuery, categoryFilter, vegFilter, priceRange, sortBy, sortOrder],
    queryFn: async () => {
      const queryString = buildSearchQuery();
      const url = queryString 
        ? `/api/restaurants/${restaurantId}/menu/search?${queryString}`
        : `/api/restaurants/${restaurantId}/menu`;
      const response = await fetch(url);
      return response.json();
    }
  });

  const menuItems = searchResponse?.items || searchResponse || [];

  // Analytics query
  const { data: analytics } = useQuery({
    queryKey: [`/api/analytics/${restaurantId}`]
  });

  // Categories query
  const { data: categoriesData } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu/categories`]
  });

  const categories = (categoriesData && categoriesData.categories) ? categoriesData.categories : [];

  // CRUD Mutations
  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/menu', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu/search`] });
      toast({ title: "Success", description: "Menu item added successfully" });
      setFormData({ name: '', description: '', price: '', category: '', isVeg: false, inStock: true, tags: '', ingredients: '' });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to add menu item", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest('PUT', `/api/menu/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu/search`] });
      toast({ title: "Success", description: "Menu item updated successfully" });
      setIsEditDialogOpen(false);
      setEditItem(null);
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to update menu item", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/menu/${id}`, undefined);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu/search`] });
      toast({ title: "Success", description: "Menu item deleted successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to delete menu item", variant: "destructive" });
    },
  });

  // Event handlers
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.description || !formData.price || !formData.category) {
      toast({ title: "Validation Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    const price = parseInt(formData.price);
    if (isNaN(price) || price <= 0) {
      toast({ title: "Validation Error", description: "Please enter a valid price", variant: "destructive" });
      return;
    }

    const submitData = {
      restaurantId, name: formData.name, description: formData.description, price: price,
      category: formData.category, isVeg: formData.isVeg, inStock: formData.inStock,
      tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()).filter(Boolean) : [],
      ingredients: formData.ingredients ? formData.ingredients.split(',').map(ing => ing.trim()).filter(Boolean) : []
    };

    createMutation.mutate(submitData);
  };

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleEdit = (item: any) => {
    setEditItem({
      ...item,
      tags: Array.isArray(item.tags) ? item.tags.join(', ') : '',
      ingredients: Array.isArray(item.ingredients) ? item.ingredients.join(', ') : ''
    });
    setIsEditDialogOpen(true);
  };

  const handleUpdate = () => {
    if (!editItem) return;
    const price = parseInt(editItem.price);
    if (isNaN(price) || price <= 0) {
      toast({ title: "Validation Error", description: "Please enter a valid price", variant: "destructive" });
      return;
    }

    const formattedData = {
      name: editItem.name, description: editItem.description, price: price,
      category: editItem.category, isVeg: editItem.isVeg, inStock: editItem.inStock,
      tags: editItem.tags ? editItem.tags.split(',').map((tag: string) => tag.trim()).filter(Boolean) : [],
      ingredients: editItem.ingredients ? editItem.ingredients.split(',').map((ing: string) => ing.trim()).filter(Boolean) : [],
      restaurantId
    };

    updateMutation.mutate({ id: editItem.id, data: formattedData });
  };

  const handleDelete = (id: number, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"? This action cannot be undone.`)) {
      deleteMutation.mutate(id);
    }
  };

  const clearFilters = () => {
    setSearchQuery(''); setCategoryFilter('all'); setVegFilter('all');
    setPriceRange({ min: '', max: '' }); setSortBy('name'); setSortOrder('asc');
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-6xl">
      <Tabs defaultValue="menu" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="menu">Menu Management</TabsTrigger>
          <TabsTrigger value="search">Advanced Search</TabsTrigger>
          <TabsTrigger value="analytics">Analytics Dashboard</TabsTrigger>
          <TabsTrigger value="orders">Order Tracking</TabsTrigger>
        </TabsList>

        {/* Menu Management Tab */}
        <TabsContent value="menu" className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Add New Menu Item</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Item Name *</Label>
                  <Input
                    id="name" value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="e.g., Butter Chicken" required
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Category *</Label>
                  <Input
                    id="category" value={formData.category}
                    onChange={(e) => handleChange('category', e.target.value)}
                    placeholder="e.g., Main Course, Appetizer" required
                  />
                </div>
                
                <div>
                  <Label htmlFor="price">Price (₹) *</Label>
                  <Input
                    id="price" type="number" value={formData.price}
                    onChange={(e) => handleChange('price', e.target.value)}
                    placeholder="e.g., 299" required
                  />
                </div>
                
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.isVeg}
                      onCheckedChange={(checked) => handleChange('isVeg', checked)}
                    />
                    <Label>Vegetarian</Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={formData.inStock}
                      onCheckedChange={(checked) => handleChange('inStock', checked)}
                    />
                    <Label>In Stock</Label>
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="description">Description *</Label>
                <Textarea
                  id="description" value={formData.description}
                  onChange={(e) => handleChange('description', e.target.value)}
                  placeholder="Describe the dish..." required
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="ingredients">Ingredients (comma separated)</Label>
                  <Input
                    id="ingredients" value={formData.ingredients}
                    onChange={(e) => handleChange('ingredients', e.target.value)}
                    placeholder="e.g., chicken, tomato, cream, spices"
                  />
                </div>
                
                <div>
                  <Label htmlFor="tags">Tags (comma separated)</Label>
                  <Input
                    id="tags" value={formData.tags}
                    onChange={(e) => handleChange('tags', e.target.value)}
                    placeholder="e.g., spicy, popular, creamy"
                  />
                </div>
              </div>
              
              <Button type="submit" className="w-full md:w-auto px-8" disabled={createMutation.isPending}>
                {createMutation.isPending ? 'Adding...' : 'Add Menu Item'}
              </Button>
            </form>
          </div>

          {/* Current Menu Items with Edit/Delete */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Current Menu Items</h3>
            
            {isLoading ? (
              <div className="text-center py-8">Loading menu items...</div>
            ) : menuItems && menuItems.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {menuItems.map((item: any) => (
                  <div key={item.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-semibold text-lg">{item.name}</h4>
                      <div className="flex space-x-2">
                        <Button
                          size="sm" variant="outline"
                          onClick={() => handleEdit(item)}
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm" variant="destructive"
                          onClick={() => handleDelete(item.id, item.name)}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">{item.description}</p>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-lg font-bold text-green-600">₹{item.price}</span>
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded">{item.category}</span>
                    </div>
                    <div className="flex gap-2">
                      {item.isVeg && (
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Vegetarian</span>
                      )}
                      <span className={`text-xs px-2 py-1 rounded ${
                        item.inStock ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {item.inStock ? 'In Stock' : 'Out of Stock'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">No menu items yet. Add your first item above!</div>
            )}
          </div>
        </TabsContent>

        {/* Advanced Search Tab */}
        <TabsContent value="search" className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Advanced Menu Search & Filters</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <Label htmlFor="searchQuery">Search Items</Label>
                <Input
                  id="searchQuery" value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by name, ingredients..."
                />
              </div>
              
              <div>
                <Label htmlFor="categoryFilter">Category</Label>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category: string) => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="vegFilter">Dietary Type</Label>
                <Select value={vegFilter} onValueChange={setVegFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Items</SelectItem>
                    <SelectItem value="true">Vegetarian Only</SelectItem>
                    <SelectItem value="false">Non-Vegetarian Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="priceMin">Min Price (₹)</Label>
                <Input
                  id="priceMin" type="number" value={priceRange.min}
                  onChange={(e) => setPriceRange(prev => ({ ...prev, min: e.target.value }))}
                  placeholder="0"
                />
              </div>
              
              <div>
                <Label htmlFor="priceMax">Max Price (₹)</Label>
                <Input
                  id="priceMax" type="number" value={priceRange.max}
                  onChange={(e) => setPriceRange(prev => ({ ...prev, max: e.target.value }))}
                  placeholder="1000"
                />
              </div>
              
              <div>
                <Label htmlFor="sortBy">Sort By</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Name</SelectItem>
                    <SelectItem value="price">Price</SelectItem>
                    <SelectItem value="category">Category</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex gap-4 mb-6">
              <Button onClick={clearFilters} variant="outline">Clear Filters</Button>
              <Button onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')} variant="outline">
                Sort: {sortOrder === 'asc' ? 'Ascending' : 'Descending'}
              </Button>
            </div>
            
            {/* Search Results */}
            <div className="border-t pt-6">
              <h4 className="font-semibold mb-4">
                Search Results ({menuItems.length} items)
                {searchResponse?.pagination && (
                  <span className="text-sm text-gray-500 ml-2">
                    (Page {searchResponse.pagination.page} of {searchResponse.pagination.totalPages})
                  </span>
                )}
              </h4>
              
              {menuItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {menuItems.map((item: any) => (
                    <div key={item.id} className="border border-gray-200 rounded-lg p-4">
                      <h5 className="font-semibold">{item.name}</h5>
                      <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-green-600">₹{item.price}</span>
                        <span className="text-xs bg-gray-100 px-2 py-1 rounded">{item.category}</span>
                      </div>
                      {item.tags && item.tags.length > 0 && (
                        <div className="mt-2">
                          {item.tags.map((tag: string, index: number) => (
                            <span key={index} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded mr-1">
                              {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">No items match your search criteria</div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* Analytics Dashboard Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Restaurant Analytics Dashboard</h3>
            
            {analytics && typeof analytics === 'object' ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Total Orders</h4>
                  <p className="text-2xl font-bold text-blue-600">{(analytics as any).totalOrders || 0}</p>
                </div>
                
                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-green-800">Total Revenue</h4>
                  <p className="text-2xl font-bold text-green-600">₹{(analytics as any).revenue || 0}</p>
                </div>
                
                <div className="bg-amber-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-amber-800">Pending Orders</h4>
                  <p className="text-2xl font-bold text-amber-600">{(analytics as any).pendingOrders || 0}</p>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-purple-800">Avg Order Value</h4>
                  <p className="text-2xl font-bold text-purple-600">₹{(analytics as any).averageOrderValue || 0}</p>
                </div>
                
                <div className="bg-indigo-50 p-4 rounded-lg">
                  <h4 className="font-semibold text-indigo-800">Returning Customers</h4>
                  <p className="text-2xl font-bold text-indigo-600">{(analytics as any).returningCustomerPercentage || 0}%</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">Loading analytics data...</div>
            )}
            
            {analytics && (analytics as any).mostOrderedItems && Array.isArray((analytics as any).mostOrderedItems) && (
              <div className="mt-8">
                <h4 className="font-semibold mb-4">Most Ordered Items</h4>
                <div className="space-y-2">
                  {(analytics as any).mostOrderedItems.map((item: any, index: number) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>{item.name}</span>
                      <span className="font-semibold">{item.count} orders</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Order Tracking Tab */}
        <TabsContent value="orders" className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Order Status & Tracking</h3>
            
            <div className="space-y-4">
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-semibold">Order Status Management</h4>
                <p className="text-sm text-gray-600 mb-4">Track and update order statuses in real-time</p>
                
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center p-3 bg-yellow-50 rounded">
                    <div className="w-8 h-8 bg-yellow-500 rounded-full mx-auto mb-2"></div>
                    <span className="text-sm font-medium">Placed</span>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded">
                    <div className="w-8 h-8 bg-blue-500 rounded-full mx-auto mb-2"></div>
                    <span className="text-sm font-medium">Confirmed</span>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded">
                    <div className="w-8 h-8 bg-orange-500 rounded-full mx-auto mb-2"></div>
                    <span className="text-sm font-medium">Preparing</span>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded">
                    <div className="w-8 h-8 bg-purple-500 rounded-full mx-auto mb-2"></div>
                    <span className="text-sm font-medium">On the Way</span>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded">
                    <div className="w-8 h-8 bg-green-500 rounded-full mx-auto mb-2"></div>
                    <span className="text-sm font-medium">Delivered</span>
                  </div>
                </div>
              </div>
              
              <div className="p-4 border border-gray-200 rounded-lg">
                <h4 className="font-semibold mb-3">Data Validation & Error Handling</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <h5 className="font-medium text-green-600">✓ Input Validation</h5>
                    <ul className="text-gray-600 space-y-1">
                      <li>• Price format validation</li>
                      <li>• Required field checks</li>
                      <li>• Category restrictions</li>
                      <li>• Tag format validation</li>
                    </ul>
                  </div>
                  <div>
                    <h5 className="font-medium text-blue-600">✓ Error Handling</h5>
                    <ul className="text-gray-600 space-y-1">
                      <li>• Graceful error messages</li>
                      <li>• Network failure recovery</li>
                      <li>• User-friendly feedback</li>
                      <li>• Validation error details</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Menu Item</DialogTitle>
          </DialogHeader>
          {editItem && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-name">Name</Label>
                  <Input
                    id="edit-name" value={editItem.name}
                    onChange={(e) => setEditItem({ ...editItem, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-category">Category</Label>
                  <Input
                    id="edit-category" value={editItem.category}
                    onChange={(e) => setEditItem({ ...editItem, category: e.target.value })}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description" value={editItem.description}
                  onChange={(e) => setEditItem({ ...editItem, description: e.target.value })}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-price">Price (₹)</Label>
                  <Input
                    id="edit-price" type="number" value={editItem.price}
                    onChange={(e) => setEditItem({ ...editItem, price: e.target.value })}
                  />
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={editItem.isVeg}
                      onCheckedChange={(checked) => setEditItem({ ...editItem, isVeg: checked })}
                    />
                    <Label>Vegetarian</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={editItem.inStock}
                      onCheckedChange={(checked) => setEditItem({ ...editItem, inStock: checked })}
                    />
                    <Label>In Stock</Label>
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="edit-ingredients">Ingredients</Label>
                  <Input
                    id="edit-ingredients" value={editItem.ingredients}
                    onChange={(e) => setEditItem({ ...editItem, ingredients: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-tags">Tags</Label>
                  <Input
                    id="edit-tags" value={editItem.tags}
                    onChange={(e) => setEditItem({ ...editItem, tags: e.target.value })}
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={handleUpdate} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? 'Updating...' : 'Update Item'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ComprehensiveMenuManager;