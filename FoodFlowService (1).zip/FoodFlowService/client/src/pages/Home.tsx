import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FilterOptions } from '@shared/types';
import RestaurantCard from '@/components/restaurant/RestaurantCard';
import Filters from '@/components/layout/Filters';
import { useLocation } from 'wouter';

const Home = () => {
  const [location] = useLocation();
  const [searchParams, setSearchParams] = useState<URLSearchParams | null>(null);
  const [filters, setFilters] = useState<FilterOptions>({
    filters: {}
  });
  
  useEffect(() => {
    // Parse search params from URL
    const params = new URLSearchParams(window.location.search);
    setSearchParams(params);
    
    // Initialize filters from URL parameters if any
    const initialFilters: FilterOptions = { filters: {} };
    
    if (params.get('sortBy')) {
      initialFilters.sortBy = params.get('sortBy') as any;
    }
    
    if (params.get('cuisine')) {
      initialFilters.filters.cuisine = params.get('cuisine')?.split(',');
    }
    
    if (params.get('veg') === 'true') {
      initialFilters.filters.veg = true;
    }
    
    if (params.get('maxDeliveryTime')) {
      initialFilters.filters.maxDeliveryTime = parseInt(params.get('maxDeliveryTime') || '30');
    }
    
    if (params.get('priceRange')) {
      const [min, max] = params.get('priceRange')?.split('-').map(Number) || [0, 0];
      initialFilters.filters.priceRange = [min, max];
    }
    
    setFilters(initialFilters);
  }, [location]);
  
  // Build query string for the API
  const buildQueryString = () => {
    const params = new URLSearchParams();
    
    if (filters.sortBy) {
      params.append('sortBy', filters.sortBy);
    }
    
    if (filters.filters.cuisine?.length) {
      params.append('cuisine', filters.filters.cuisine.join(','));
    }
    
    if (filters.filters.veg) {
      params.append('veg', 'true');
    }
    
    if (filters.filters.maxDeliveryTime) {
      params.append('maxDeliveryTime', filters.filters.maxDeliveryTime.toString());
    }
    
    if (filters.filters.priceRange) {
      params.append('priceRange', filters.filters.priceRange.join('-'));
    }
    
    // Add search term if present in URL
    if (searchParams?.get('search')) {
      params.append('search', searchParams.get('search') || '');
    }
    
    return params.toString();
  };
  
  const { data: restaurants, isLoading, error } = useQuery({
    queryKey: [`/api/restaurants?${buildQueryString()}`],
  });
  
  const handleFilterChange = (newFilters: FilterOptions) => {
    setFilters(newFilters);
  };
  
  return (
    <main>
      <Filters onFilterChange={handleFilterChange} currentFilters={filters} />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-secondary mb-1 brand-font">Restaurants in your area</h1>
        <p className="text-textGray mb-6">Discover amazing food from these restaurants</p>
        
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <p className="text-red-500 mb-2">Failed to load restaurants</p>
            <p className="text-textGray">Please try again later</p>
          </div>
        ) : restaurants?.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl text-gray-300 mb-4">
              <i className="fas fa-utensils"></i>
            </div>
            <h3 className="text-xl font-medium text-secondary mb-2">No restaurants found</h3>
            <p className="text-textGray mb-6">Try adjusting your filters or search criteria</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {restaurants?.map((restaurant) => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} />
            ))}
          </div>
        )}
      </div>
    </main>
  );
};

export default Home;
