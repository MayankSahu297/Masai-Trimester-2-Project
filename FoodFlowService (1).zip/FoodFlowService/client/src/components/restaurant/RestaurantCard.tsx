import { Link } from 'wouter';
import { Restaurant } from '@shared/schema';

type RestaurantCardProps = {
  restaurant: Restaurant;
};

const RestaurantCard = ({ restaurant }: RestaurantCardProps) => {
  const {
    id,
    name,
    cuisineTypes,
    rating,
    deliveryTime,
    priceForTwo,
    imageUrl,
    offers
  } = restaurant;
  
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow border border-gray-100">
      <img 
        src={imageUrl}
        alt={`${name} restaurant dish`} 
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <div className="flex justify-between items-start">
          <h3 className="font-bold text-lg text-secondary">{name}</h3>
          <span className="bg-success text-white px-1.5 py-0.5 text-sm rounded flex items-center">
            <span>{rating}</span>
            <i className="fas fa-star text-xs ml-1"></i>
          </span>
        </div>
        <p className="text-textGray text-sm mt-1">{cuisineTypes.join(", ")}</p>
        <div className="flex items-center mt-2 text-sm text-textGray">
          <span className="flex items-center">
            <i className="fas fa-clock mr-1 text-textGray"></i> {deliveryTime} mins
          </span>
          <span className="mx-2">•</span>
          <span>₹{priceForTwo} for two</span>
        </div>
        {offers && offers.length > 0 && (
          <div className="mt-3 pt-3 border-t border-gray-100 flex items-center text-sm">
            <i className="fas fa-tag text-primary mr-2"></i>
            <span className="text-textGray">{offers[0]}</span>
          </div>
        )}
      </div>
      <Link href={`/restaurant/${id}`}>
        <div className="bg-blue-50 p-3 text-center cursor-pointer hover:bg-blue-100 transition-colors">
          <span className="text-blue-600 font-medium">QUICK VIEW</span>
        </div>
      </Link>
    </div>
  );
};

export default RestaurantCard;
