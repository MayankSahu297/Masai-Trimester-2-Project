import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { MenuItem } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

type MenuManagementProps = {
  restaurantId: number;
};

// Menu item form schema
const menuItemSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  price: z.number().min(1, "Price must be greater than 0"),
  category: z.string().min(1, "Category is required"),
  imageUrl: z.string().optional(),
  isVeg: z.boolean(),
  inStock: z.boolean(),
  tags: z.string().optional(), // Will convert to array when submitting
  ingredients: z.string().optional(), // Will convert to array when submitting
});

type MenuItemFormData = z.infer<typeof menuItemSchema>;

const MenuManagement = ({ restaurantId }: MenuManagementProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  
  const { data: menuItems, isLoading } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu`],
  });
  
  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest('POST', '/api/menu', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      toast({
        title: "Success",
        description: "Menu item created successfully",
      });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create menu item",
        variant: "destructive",
      });
    },
  });
  
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const res = await apiRequest('PUT', `/api/menu/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      toast({
        title: "Success",
        description: "Menu item updated successfully",
      });
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update menu item",
        variant: "destructive",
      });
    },
  });
  
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/menu/${id}`, undefined);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/restaurants/${restaurantId}/menu`] });
      toast({
        title: "Success",
        description: "Menu item deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete menu item",
        variant: "destructive",
      });
    },
  });
  
  const form = useForm<MenuItemFormData>({
    resolver: zodResolver(menuItemSchema),
    defaultValues: {
      name: '',
      description: '',
      price: 0,
      category: '',
      imageUrl: '',
      isVeg: false,
      inStock: true,
      tags: '',
      ingredients: '',
    },
  });
  
  const handleOpenDialog = (item?: MenuItem) => {
    if (item) {
      setEditingItem(item);
      form.reset({
        name: item.name,
        description: item.description,
        price: item.price,
        category: item.category,
        imageUrl: item.imageUrl || '',
        isVeg: item.isVeg,
        inStock: item.inStock,
        tags: item.tags?.join(', ') || '',
        ingredients: item.ingredients?.join(', ') || '',
      });
    } else {
      setEditingItem(null);
      form.reset({
        name: '',
        description: '',
        price: 0,
        category: '',
        imageUrl: '',
        isVeg: false,
        inStock: true,
        tags: '',
        ingredients: '',
      });
    }
    setIsDialogOpen(true);
  };
  
  const handleDeleteItem = (id: number) => {
    if (confirm('Are you sure you want to delete this menu item?')) {
      deleteMutation.mutate(id);
    }
  };
  
  const onSubmit = (data: MenuItemFormData) => {
    // Convert string price to number
    const numericPrice = typeof data.price === 'string' 
      ? parseInt(data.price as unknown as string, 10) 
      : data.price;
    
    // Convert comma-separated strings to arrays
    const tags = data.tags 
      ? data.tags.split(',').map(tag => tag.trim()).filter(Boolean) 
      : undefined;
      
    const ingredients = data.ingredients 
      ? data.ingredients.split(',').map(ingredient => ingredient.trim()).filter(Boolean) 
      : undefined;
    
    const formattedData = {
      ...data,
      price: numericPrice,
      tags,
      ingredients,
      restaurantId,
    };
    
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formattedData });
    } else {
      createMutation.mutate(formattedData);
    }
  };
  
  const isPending = createMutation.isPending || updateMutation.isPending;
  
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-bold text-secondary">Menu Management</h2>
        <Button 
          onClick={() => handleOpenDialog()} 
          className="bg-success text-white px-3 py-1.5 rounded-lg text-sm hover:bg-green-600 transition-colors"
        >
          <i className="fas fa-plus mr-1"></i> Add Item
        </Button>
      </div>
      <div className="overflow-x-auto">
        {isLoading ? (
          <div className="text-center py-4">Loading menu items...</div>
        ) : (
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-xs text-textGray border-b border-gray-200">
                <th className="pb-2">Item Name</th>
                <th className="pb-2">Category</th>
                <th className="pb-2">Price</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {menuItems?.map((item: MenuItem) => (
                <tr key={item.id} className="border-b border-gray-100">
                  <td className="py-3 pr-4">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-md overflow-hidden mr-2 bg-gray-100">
                        {item.imageUrl ? (
                          <img 
                            src={item.imageUrl} 
                            alt={item.name} 
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-400">
                            <i className="fas fa-utensils"></i>
                          </div>
                        )}
                      </div>
                      <span className="text-sm text-secondary">{item.name}</span>
                    </div>
                  </td>
                  <td className="py-3 pr-4">
                    <span className="text-xs text-textGray">{item.category}</span>
                  </td>
                  <td className="py-3 pr-4">
                    <span className="text-sm text-secondary">₹{item.price}</span>
                  </td>
                  <td className="py-3 pr-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      item.inStock 
                        ? 'bg-green-100 text-success' 
                        : 'bg-red-100 text-red-600'
                    }`}>
                      {item.inStock ? 'Available' : 'Out of Stock'}
                    </span>
                  </td>
                  <td className="py-3">
                    <div className="flex space-x-2">
                      <button 
                        onClick={() => handleOpenDialog(item)} 
                        className="text-blue-600 hover:text-blue-800"
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        onClick={() => handleDeleteItem(item.id)}
                        className="text-red-600 hover:text-red-800"
                      >
                        <i className="fas fa-trash-alt"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      
      {/* Add/Edit Menu Item Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Menu Item" : "Add New Menu Item"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="grid gap-4 py-4 grid-cols-2">
              <div className="grid gap-2 col-span-2 sm:col-span-1">
                <Label htmlFor="name">Name</Label>
                <Input id="name" {...form.register('name')} />
                {form.formState.errors.name && (
                  <p className="text-red-500 text-sm">{form.formState.errors.name.message}</p>
                )}
              </div>
              <div className="grid gap-2 col-span-2 sm:col-span-1">
                <Label htmlFor="category">Category</Label>
                <Input id="category" {...form.register('category')} />
                {form.formState.errors.category && (
                  <p className="text-red-500 text-sm">{form.formState.errors.category.message}</p>
                )}
              </div>
              <div className="grid gap-2 col-span-2 sm:col-span-1">
                <Label htmlFor="price">Price (₹)</Label>
                <Input 
                  id="price" 
                  type="number" 
                  {...form.register('price', { valueAsNumber: true })} 
                />
                {form.formState.errors.price && (
                  <p className="text-red-500 text-sm">{form.formState.errors.price.message}</p>
                )}
              </div>
              <div className="grid gap-2 col-span-2 sm:col-span-1">
                <Label htmlFor="imageUrl">Image URL</Label>
                <Input id="imageUrl" {...form.register('imageUrl')} />
              </div>
              <div className="grid gap-2 col-span-2">
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" {...form.register('description')} />
                {form.formState.errors.description && (
                  <p className="text-red-500 text-sm">{form.formState.errors.description.message}</p>
                )}
              </div>
              <div className="grid gap-2 col-span-2">
                <Label htmlFor="ingredients">Ingredients (comma separated)</Label>
                <Textarea id="ingredients" {...form.register('ingredients')} />
              </div>
              <div className="grid gap-2 col-span-2">
                <Label htmlFor="tags">Tags (comma separated)</Label>
                <Input id="tags" {...form.register('tags')} />
              </div>
              <div className="flex items-center gap-2 col-span-1">
                <Switch 
                  id="isVeg" 
                  checked={form.watch('isVeg')}
                  onCheckedChange={value => form.setValue('isVeg', value)}
                />
                <Label htmlFor="isVeg">Vegetarian</Label>
              </div>
              <div className="flex items-center gap-2 col-span-1">
                <Switch 
                  id="inStock" 
                  checked={form.watch('inStock')}
                  onCheckedChange={value => form.setValue('inStock', value)}
                />
                <Label htmlFor="inStock">In Stock</Label>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={isPending}>
                {isPending ? 'Saving...' : 'Save'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MenuManagement;
